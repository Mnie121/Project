import { Link } from 'react-router-dom';

export default function Footer() {
  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const email = (form.elements.namedItem('email') as HTMLInputElement).value;
    alert(`Спасибо за подписку: ${email}`);
    form.reset();
  };

  return (
    <footer className="bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-white transition-colors">
      <div className="max-w-[1400px] mx-auto px-8 py-20">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          <div>
            <h3 className="text-2xl font-bold mb-6">Будьте в курсе</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-6 text-sm">
              Подпишитесь на нашу рассылку, чтобы получать эксклюзивные предложения и новинки.
            </p>
            <form onSubmit={handleNewsletterSubmit} className="flex gap-2">
              <input
                type="email"
                name="email"
                placeholder="Введите ваш email"
                required
                className="flex-1 px-4 py-3 rounded-lg bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 text-gray-900 dark:text-white text-sm focus:outline-none focus:border-gray-900 dark:focus:border-gray-400"
              />
              <button
                type="submit"
                className="px-6 py-3 bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900 rounded-lg font-medium hover:bg-gray-800 dark:hover:bg-gray-200 transition-colors whitespace-nowrap"
              >
                Подписаться
              </button>
            </form>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6">Быстрые ссылки</h4>
            <div className="flex flex-col gap-3">
              <Link to="/" className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors text-sm">
                Главная
              </Link>
              <Link to="/catalog" className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors text-sm">
                Каталог
              </Link>
              <Link to="/orders" className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors text-sm">
                История заказов
              </Link>
              <Link to="/compare" className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors text-sm">
                Сравнение товаров
              </Link>
              <Link to="/about" className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors text-sm">
                О нас
              </Link>
              <Link to="/profile" className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors text-sm">
                Мой профиль
              </Link>
              <Link to="/feedback" className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors text-sm">
                Отзывы
              </Link>
              <Link to="/wishlist" className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors text-sm">
                Желаемое
              </Link>
              <Link to="/cart" className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors text-sm">
                Корзина
              </Link>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6">Контактная информация</h4>
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-3">
                <i className="ri-phone-line text-xl text-gray-700 dark:text-gray-400"></i>
                <span className="text-gray-600 dark:text-gray-400 text-sm">+7 778 123 4567</span>
              </div>
              <div className="flex items-center gap-3">
                <i className="ri-mail-line text-xl text-gray-700 dark:text-gray-400"></i>
                <span className="text-gray-600 dark:text-gray-400 text-sm">support@kiristore.com</span>
              </div>
              <div className="flex items-center gap-3">
                <i className="ri-map-pin-line text-xl text-gray-700 dark:text-gray-400"></i>
                <span className="text-gray-600 dark:text-gray-400 text-sm">ул. Кабдолова 1/4, Алматы 050000</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-300 dark:border-gray-700 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex gap-6">
            <a href="https://www.facebook.com/p/Kiristore-100083013228369/"><i className="ri-facebook-circle-fill text-2xl text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white cursor-pointer transition-colors"></i></a>
            <a href="https://x.com/Store"><i className="ri-twitter-x-fill text-2xl text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white cursor-pointer transition-colors"></i></a>
            <a href="https://www.instagram.com/kiri_stores/"><i className="ri-instagram-line text-2xl text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white cursor-pointer transition-colors"></i></a>
            <a href="https://www.linkedin.com/company/storeprojects"><i className="ri-linkedin-box-fill text-2xl text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white cursor-pointer transition-colors"></i></a>
          </div>

          <p className="text-gray-600 dark:text-gray-400 text-sm">© 2026 KiriStore. Все права защищены.</p>

        </div>
      </div>
    </footer>
  );
}
