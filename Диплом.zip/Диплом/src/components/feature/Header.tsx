import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useTheme } from '../../contexts/ThemeContext';

interface CartItem {
  id: number;
  quantity: number;
}

export default function Header() {
  const [cartCount, setCartCount] = useState(0);
  const [wishlistCount, setWishlistCount] = useState(0);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();
  const { theme, toggleTheme } = useTheme();

  useEffect(() => {
    const updateCartCount = () => {
      const cart = JSON.parse(localStorage.getItem('cart') || '[]') as CartItem[];
      const total = cart.reduce((sum, item) => sum + item.quantity, 0);
      setCartCount(total);
    };

    const updateWishlistCount = () => {
      const wishlist = JSON.parse(localStorage.getItem('wishlist') || '[]');
      setWishlistCount(wishlist.length);
    };

    updateCartCount();
    updateWishlistCount();
    window.addEventListener('storage', updateCartCount);
    window.addEventListener('cartUpdated', updateCartCount);
    window.addEventListener('storage', updateWishlistCount);
    window.addEventListener('wishlistUpdated', updateWishlistCount);

    return () => {
      window.removeEventListener('storage', updateCartCount);
      window.removeEventListener('cartUpdated', updateCartCount);
      window.removeEventListener('storage', updateWishlistCount);
      window.removeEventListener('wishlistUpdated', updateWishlistCount);
    };
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const isHomePage = location.pathname === '/';

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled || !isHomePage ? 'bg-white dark:bg-gray-900 shadow-md' : 'bg-transparent'
      }`}
    >
      <div className="max-w-[1400px] mx-auto px-8 h-[72px] flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3 whitespace-nowrap">
          <div className="w-10 h-10 bg-gradient-to-br from-gray-900 to-gray-700 dark:from-gray-100 dark:to-gray-300 rounded-lg flex items-center justify-center"><i className="ri-shopping-bag-3-fill text-2xl text-white dark:text-gray-900"></i></div>
          <span className={`text-xl font-bold transition-colors ${isScrolled || !isHomePage ? 'text-gray-900 dark:text-white' : 'text-gray-900 dark:text-white'}`}>
            KiriStore
          </span>
        </Link>

        <nav className="flex items-center gap-8">
          <Link
            to="/"
            className={`text-sm font-medium transition-all hover:opacity-70 whitespace-nowrap ${
              isScrolled || !isHomePage ? 'text-gray-700 dark:text-gray-300' : 'text-gray-900 dark:text-white'
            }`}
          >
            Главная
          </Link>
          <Link
            to="/catalog"
            className={`text-sm font-medium transition-all hover:opacity-70 whitespace-nowrap ${
              isScrolled || !isHomePage ? 'text-gray-700 dark:text-gray-300' : 'text-gray-900 dark:text-white'
            }`}
          >
            Каталог
          </Link>
          <Link
            to="/orders"
            className={`text-sm font-medium transition-all hover:opacity-70 whitespace-nowrap ${
              isScrolled || !isHomePage ? 'text-gray-700 dark:text-gray-300' : 'text-gray-900 dark:text-white'
            }`}
          >
            Заказы
          </Link>
          <Link
            to="/compare"
            className={`text-sm font-medium transition-all hover:opacity-70 whitespace-nowrap ${
              isScrolled || !isHomePage ? 'text-gray-700 dark:text-gray-300' : 'text-gray-900 dark:text-white'
            }`}
          >
            Сравнение
          </Link>
          <Link
            to="/about"
            className={`text-sm font-medium transition-all hover:opacity-70 whitespace-nowrap ${
              isScrolled || !isHomePage ? 'text-gray-700 dark:text-gray-300' : 'text-gray-900 dark:text-white'
            }`}
          >
            О нас
          </Link>
          <Link
            to="/feedback"
            className={`text-sm font-medium transition-all hover:opacity-70 whitespace-nowrap ${
              isScrolled || !isHomePage ? 'text-gray-700 dark:text-gray-300' : 'text-gray-900 dark:text-white'
            }`}
          >
            Отзывы
          </Link>
        </nav>

        <div className="flex items-center gap-6">
          <button
            onClick={toggleTheme}
            className={`cursor-pointer transition-colors ${isScrolled || !isHomePage ? 'text-gray-700 dark:text-gray-300' : 'text-gray-900 dark:text-white'}`}
            aria-label="Toggle theme"
          >
            {theme === 'light' ? (
              <i className="ri-moon-line text-2xl"></i>
            ) : (
              <i className="ri-sun-line text-2xl"></i>
            )}
          </button>
          <Link to="/wishlist" className="relative cursor-pointer">
            <i className={`ri-heart-line text-2xl transition-colors ${isScrolled || !isHomePage ? 'text-gray-700 dark:text-gray-300' : 'text-gray-900 dark:text-white'}`}></i>
            {wishlistCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                {wishlistCount}
              </span>
            )}
          </Link>
          <Link to="/cart" className="relative cursor-pointer">
            <i className={`ri-shopping-cart-line text-2xl transition-colors ${isScrolled || !isHomePage ? 'text-gray-700 dark:text-gray-300' : 'text-gray-900 dark:text-white'}`}></i>
            {cartCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900 text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </Link>
          <Link to="/profile" className="cursor-pointer">
            <i className={`ri-user-line text-2xl transition-colors ${isScrolled || !isHomePage ? 'text-gray-700 dark:text-gray-300' : 'text-gray-900 dark:text-white'}`}></i>
          </Link>
        </div>
      </div>
    </header>
  );
}
