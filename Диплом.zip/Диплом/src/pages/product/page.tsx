import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';

interface Product {
  id: number;
  title: string;
  description: string;
  price: number;
  discountPercentage: number;
  rating: number;
  stock: number;
  brand: string;
  category: string;
  thumbnail: string;
  images: string[];
}

export default function ProductPage() {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const [selectedImage, setSelectedImage] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [showSuccess, setShowSuccess] = useState(false);
  const [isInCompare, setIsInCompare] = useState(false);
  const [isInWishlist, setIsInWishlist] = useState(false);
  const [showCompareNotification, setShowCompareNotification] = useState<{
    show: boolean;
    message: string;
    type: 'success' | 'error';
  }>({ show: false, message: '', type: 'success' });

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        setLoading(true);
        const response = await fetch(`https://dummyjson.com/products/${id}`);
        if (!response.ok) throw new Error('Product not found');
        const data = await response.json();
        setProduct(data);

        // Check if product is in compare list
        const compareList = JSON.parse(localStorage.getItem('compareList') || '[]');
        setIsInCompare(compareList.includes(data.id));

        // Check if product is in wishlist
        const wishlistItems = JSON.parse(localStorage.getItem('wishlist') || '[]');
        setIsInWishlist(wishlistItems.some((item: any) => item.id === data.id));

        const relatedResponse = await fetch(
          `https://dummyjson.com/products/category/${data.category}?limit=4`
        );
        const relatedData = await relatedResponse.json();
        setRelatedProducts(
          relatedData.products.filter((p: Product) => p.id !== data.id).slice(0, 4)
        );
      } catch (err) {
        setError('Не удалось загрузить товар. Пожалуйста, попробуйте позже.');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchProduct();
    window.scrollTo(0, 0);
  }, [id]);

  const addToCart = () => {
    if (!product) return;

    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const existingItem = cart.find((item: any) => item.id === product.id);

    if (existingItem) {
      existingItem.quantity += quantity;
    } else {
      cart.push({
        id: product.id,
        title: product.title,
        price: product.price,
        thumbnail: product.thumbnail,
        quantity,
      });
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    window.dispatchEvent(new Event('cartUpdated'));
    
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  const addToCompare = () => {
    if (!product) return;

    const compareList = JSON.parse(localStorage.getItem('compareList') || '[]');

    if (compareList.includes(product.id)) {
      setShowCompareNotification({
        show: true,
        message: 'Товар уже в списке сравнения',
        type: 'error',
      });
      setTimeout(() => setShowCompareNotification({ show: false, message: '', type: 'success' }), 3000);
      return;
    }

    if (compareList.length >= 4) {
      setShowCompareNotification({
        show: true,
        message: 'Максимум 4 товара для сравнения',
        type: 'error',
      });
      setTimeout(() => setShowCompareNotification({ show: false, message: '', type: 'success' }), 3000);
      return;
    }

    compareList.push(product.id);
    localStorage.setItem('compareList', JSON.stringify(compareList));

    // Save full product data
    const compareProducts = JSON.parse(localStorage.getItem('compareProducts') || '[]');
    compareProducts.push(product);
    localStorage.setItem('compareProducts', JSON.stringify(compareProducts));

    setIsInCompare(true);
    setShowCompareNotification({
      show: true,
      message: 'Добавлено в сравнение',
      type: 'success',
    });
    setTimeout(() => setShowCompareNotification({ show: false, message: '', type: 'success' }), 3000);
  };

  const toggleWishlist = () => {
    if (!product) return;

    const saved: any[] = JSON.parse(localStorage.getItem('wishlist') || '[]');
    const exists = saved.find((item) => item.id === product.id);

    if (exists) {
      const updated = saved.filter((item) => item.id !== product.id);
      localStorage.setItem('wishlist', JSON.stringify(updated));
      setIsInWishlist(false);
      setShowCompareNotification({
        show: true,
        message: 'Удалено из желаемого',
        type: 'success',
      });
    } else {
      const newItem = {
        id: product.id,
        title: product.title,
        price: product.price,
        thumbnail: product.thumbnail,
        category: product.category,
        rating: product.rating,
      };
      saved.push(newItem);
      localStorage.setItem('wishlist', JSON.stringify(saved));
      setIsInWishlist(true);
      setShowCompareNotification({
        show: true,
        message: 'Добавлено в желаемое',
        type: 'success',
      });
    }

    window.dispatchEvent(new Event('wishlistUpdated'));
    setTimeout(() => setShowCompareNotification({ show: false, message: '', type: 'success' }), 3000);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-white dark:bg-gray-900">
        <Header />
        <div className="flex justify-center items-center h-screen">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900 dark:border-gray-100"></div>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="min-h-screen bg-white dark:bg-gray-900">
        <Header />
        <div className="flex flex-col justify-center items-center h-screen">
          <i className="ri-error-warning-line text-6xl text-red-500 mb-4"></i>
          <p className="text-xl text-gray-600 dark:text-gray-400 mb-6">{error || 'Товар не найден'}</p>
          <Link
            to="/catalog"
            className="bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900 px-6 py-3 rounded-lg hover:bg-gray-800 dark:hover:bg-gray-200 transition-colors whitespace-nowrap"
          >
            Вернуться в каталог
          </Link>
        </div>
      </div>
    );
  }

  const originalPrice = product.price / (1 - product.discountPercentage / 100);

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <Header />

      {showSuccess && (
        <div className="fixed top-24 right-8 bg-green-500 text-white px-6 py-4 rounded-lg shadow-xl z-50 animate-fade-in">
          <div className="flex items-center gap-3">
            <i className="ri-checkbox-circle-line text-2xl"></i>
            <span className="font-medium">Успешно добавлено в корзину!</span>
          </div>
        </div>
      )}

      {showCompareNotification.show && (
        <div
          className={`fixed top-24 right-8 px-6 py-4 rounded-lg shadow-xl z-50 animate-fade-in ${
            showCompareNotification.type === 'success'
              ? 'bg-green-500 text-white'
              : 'bg-red-500 text-white'
          }`}
        >
          <div className="flex items-center gap-3">
            <i
              className={`text-2xl ${
                showCompareNotification.type === 'success'
                  ? 'ri-checkbox-circle-line'
                  : 'ri-error-warning-line'
              }`}
            ></i>
            <span className="font-medium">{showCompareNotification.message}</span>
          </div>
        </div>
      )}

      <main className="pt-24 pb-20">
        <div className="max-w-[1400px] mx-auto px-8">
          <div className="mb-6">
            <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
              <Link to="/" className="hover:text-gray-900 dark:hover:text-gray-200">Главная</Link>
              <i className="ri-arrow-right-s-line"></i>
              <Link to="/catalog" className="hover:text-gray-900 dark:hover:text-gray-200">Каталог</Link>
              <i className="ri-arrow-right-s-line"></i>
              <span className="text-gray-900 dark:text-white">{product.title}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-20">
            <div>
              <div className="bg-gray-100 dark:bg-gray-800 rounded-2xl overflow-hidden mb-6 aspect-square w-full h-[600px]">
                <img
                  src={product.images[selectedImage] || product.thumbnail}
                  alt={product.title}
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="grid grid-cols-5 gap-4">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`aspect-square rounded-lg overflow-hidden border-2 transition-all ${
                      selectedImage === index
                        ? 'border-gray-900 dark:border-gray-100'
                        : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                    }`}
                  >
                    <img
                      src={image}
                      alt={`${product.title} ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="mb-6">
                <span className="inline-block bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white text-xs font-bold px-3 py-1 rounded-full mb-4">
                  {product.category.toUpperCase()}
                </span>
                <h1 className="text-5xl font-bold text-gray-900 dark:text-white mb-4">{product.title}</h1>
                <div className="flex items-center gap-4 mb-6">
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <i
                        key={i}
                        className={`${
                          i < Math.floor(product.rating)
                            ? 'ri-star-fill text-yellow-400'
                            : 'ri-star-line text-gray-300 dark:text-gray-600'
                        } text-lg`}
                      ></i>
                    ))}
                  </div>
                  <span className="text-gray-600 dark:text-gray-400">({product.rating} рейтинг)</span>
                  <span className="text-gray-400 dark:text-gray-600">|</span>
                  <span className="text-gray-600 dark:text-gray-400">{product.brand}</span>
                </div>
              </div>

              <div className="mb-8">
                <div className="flex items-baseline gap-4 mb-4">
                  <p className="text-5xl font-bold text-gray-900 dark:text-white">${product.price}</p>
                  {product.discountPercentage > 0 && (
                    <>
                      <p className="text-2xl text-gray-400 dark:text-gray-500 line-through">
                        ${originalPrice.toFixed(2)}
                      </p>
                      <span className="bg-red-500 text-white text-sm font-bold px-3 py-1 rounded-full">
                        -{product.discountPercentage.toFixed(0)}%
                      </span>
                    </>
                  )}
                </div>
                <p className="text-gray-600 dark:text-gray-400 leading-relaxed">{product.description}</p>
              </div>

              <div className="mb-8">
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                  В наличии: <span className="font-semibold text-green-600 dark:text-green-400">{product.stock} шт.</span>
                </p>
                <div className="flex items-center gap-4">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Количество:</label>
                  <div className="flex items-center border border-gray-300 dark:border-gray-600 rounded-lg">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors text-gray-900 dark:text-white"
                    >
                      <i className="ri-subtract-line"></i>
                    </button>
                    <input
                      type="number"
                      value={quantity}
                      onChange={(e) => setQuantity(Math.max(1, Math.min(product.stock, parseInt(e.target.value) || 1)))}
                      className="w-16 text-center border-x border-gray-300 dark:border-gray-600 py-2 focus:outline-none bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                      min="1"
                      max={product.stock}
                    />
                    <button
                      onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                      className="px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors text-gray-900 dark:text-white"
                    >
                      <i className="ri-add-line"></i>
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex gap-4 mb-8">
                <button
                  onClick={addToCart}
                  className="flex-1 bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900 py-4 rounded-full font-medium hover:bg-gray-800 dark:hover:bg-gray-200 transition-colors flex items-center justify-center gap-2 text-lg whitespace-nowrap"
                >
                  <i className="ri-shopping-cart-line text-xl"></i>
                  В корзину
                </button>
                <button
                  onClick={toggleWishlist}
                  className={`px-6 py-4 rounded-full font-medium transition-colors flex items-center justify-center gap-2 text-lg whitespace-nowrap cursor-pointer ${
                    isInWishlist
                      ? 'bg-red-500 text-white hover:bg-red-600'
                      : 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white hover:bg-gray-200 dark:hover:bg-gray-700 border border-gray-300 dark:border-gray-600'
                  }`}
                  title={isInWishlist ? 'Удалить из желаемого' : 'Добавить в желаемое'}
                >
                  <i className={`text-xl ${isInWishlist ? 'ri-heart-fill' : 'ri-heart-line'}`}></i>
                  {isInWishlist ? 'В желаемом' : 'В желаемое'}
                </button>
                <button
                  onClick={addToCompare}
                  disabled={isInCompare}
                  className={`px-6 py-4 rounded-full font-medium transition-colors flex items-center justify-center gap-2 text-lg whitespace-nowrap ${
                    isInCompare
                      ? 'bg-gray-200 dark:bg-gray-700 text-gray-500 dark:text-gray-400 cursor-not-allowed'
                      : 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white hover:bg-gray-200 dark:hover:bg-gray-700 border border-gray-300 dark:border-gray-600'
                  }`}
                  title={isInCompare ? 'Уже в списке сравнения' : 'Добавить к сравнению'}
                >
                  <i className={`text-xl ${isInCompare ? 'ri-checkbox-circle-fill' : 'ri-git-compare-line'}`}></i>
                  {isInCompare ? 'В сравнении' : 'Сравнить'}
                </button>
              </div>

              <div className="grid grid-cols-3 gap-4 pt-8 border-t border-gray-200 dark:border-gray-700">
                <div className="text-center">
                  <i className="ri-truck-line text-3xl text-gray-900 dark:text-gray-100 mb-2"></i>
                  <p className="text-xs text-gray-600 dark:text-gray-400">Бесплатная доставка</p>
                </div>
                <div className="text-center">
                  <i className="ri-shield-check-line text-3xl text-gray-900 dark:text-gray-100 mb-2"></i>
                  <p className="text-xs text-gray-600 dark:text-gray-400">Гарантия</p>
                </div>
                <div className="text-center">
                  <i className="ri-arrow-go-back-line text-3xl text-gray-900 dark:text-gray-100 mb-2"></i>
                  <p className="text-xs text-gray-600 dark:text-gray-400">Лёгкий возврат</p>
                </div>
              </div>
            </div>
          </div>

          {relatedProducts.length > 0 && (
            <section>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">Вам также может понравиться</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8" data-product-shop>
                {relatedProducts.map((relatedProduct) => (
                  <Link
                    key={relatedProduct.id}
                    to={`/product/${relatedProduct.id}`}
                    className="bg-white dark:bg-gray-800 rounded-2xl overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-2 group border border-gray-200 dark:border-gray-700"
                  >
                    <div className="aspect-square overflow-hidden bg-gray-100 dark:bg-gray-700">
                      <img
                        src={relatedProduct.thumbnail}
                        alt={relatedProduct.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                    </div>
                    <div className="p-6">
                      <p className="text-xs text-gray-500 dark:text-gray-400 uppercase mb-2">
                        {relatedProduct.category}
                      </p>
                      <h3 className="font-semibold text-gray-900 dark:text-white mb-3 line-clamp-2 min-h-[3rem]">
                        {relatedProduct.title}
                      </h3>
                      <div className="flex items-center justify-between">
                        <p className="text-2xl font-bold text-gray-900 dark:text-white">${relatedProduct.price}</p>
                        <div className="flex items-center gap-1">
                          <i className="ri-star-fill text-yellow-400 text-sm"></i>
                          <span className="text-sm text-gray-600 dark:text-gray-400">{relatedProduct.rating}</span>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </section>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
