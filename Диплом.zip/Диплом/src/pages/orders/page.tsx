import { useState, useEffect } from 'react';
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';
import { mockOrders, Order } from '../../mocks/ordersData';

type StatusFilter = 'all' | 'delivered' | 'in-transit' | 'processing' | 'cancelled';
type SortOption = 'date-desc' | 'date-asc' | 'total-desc' | 'total-asc';

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [sortOption, setSortOption] = useState<SortOption>('date-desc');
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null);

  /** Load orders from localStorage (if any) and merge with mock data */
  useEffect(() => {
    try {
      const savedOrders = localStorage.getItem('userOrders');
      if (savedOrders) {
        const parsed = JSON.parse(savedOrders) as Order[];
        // Ensure we always work with a fresh array to avoid mutating the source
        setOrders([...parsed, ...mockOrders]);
      } else {
        setOrders(mockOrders);
      }
    } catch (e) {
      console.error('Failed to parse orders from localStorage', e);
      // Fallback to mock data on error
      setOrders(mockOrders);
    }
  }, []);

  /** Configuration for each order status */
  const getStatusConfig = (status: Order['status']) => {
    switch (status) {
      case 'delivered':
        return {
          label: 'Доставлен',
          color:
            'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400',
          icon: 'ri-checkbox-circle-line',
        };
      case 'in-transit':
        return {
          label: 'В пути',
          color:
            'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400',
          icon: 'ri-truck-line',
        };
      case 'processing':
        return {
          label: 'Обработка',
          color:
            'bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400',
          icon: 'ri-time-line',
        };
      case 'cancelled':
        return {
          label: 'Отменён',
          color:
            'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400',
          icon: 'ri-close-circle-line',
        };
      default:
        // Defensive fallback – should never happen if data is correct
        return {
          label: 'Неизвестно',
          color:
            'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300',
          icon: 'ri-question-line',
        };
    }
  };

  /** Apply status filter */
  const filteredOrders = orders.filter((order) => {
    if (statusFilter === 'all') return true;
    return order.status === statusFilter;
  });

  /** Apply sorting */
  const sortedOrders = [...filteredOrders].sort((a, b) => {
    switch (sortOption) {
      case 'date-desc':
        return new Date(b.date).getTime() - new Date(a.date).getTime();
      case 'date-asc':
        return new Date(a.date).getTime() - new Date(b.date).getTime();
      case 'total-desc':
        return b.total - a.total;
      case 'total-asc':
        return a.total - b.total;
      default:
        return 0;
    }
  });

  /** Human‑readable date formatting */
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ru-RU', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      <Header />

      <main className="pt-24 pb-20">
        <div className="max-w-[1400px] mx-auto px-8">
          <div className="mb-12">
            <h1 className="text-5xl font-bold text-gray-900 dark:text-white mb-3">
              История заказов
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              Всего заказов: {orders.length}
            </p>
          </div>

          {/* Filters and Sort */}
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 mb-8 border border-gray-200 dark:border-gray-700 transition-colors">
            <div className="flex flex-col lg:flex-row gap-6">
              {/* Status Filter */}
              <div className="flex-1">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                  Фильтр по статусу
                </label>
                <div className="flex flex-wrap gap-2">
                  {[
                    { value: 'all' as const, label: 'Все' },
                    { value: 'delivered' as const, label: 'Доставлен' },
                    { value: 'in-transit' as const, label: 'В пути' },
                    { value: 'processing' as const, label: 'Обработка' },
                    { value: 'cancelled' as const, label: 'Отменён' },
                  ].map((filter) => (
                    <button
                      key={filter.value}
                      onClick={() => setStatusFilter(filter.value)}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-all cursor-pointer whitespace-nowrap ${
                        statusFilter === filter.value
                          ? 'bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900'
                          : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                      }`}
                    >
                      {filter.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Sort */}
              <div className="lg:w-64">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                  Сортировка
                </label>
                <select
                  value={sortOption}
                  onChange={(e) => setSortOption(e.target.value as SortOption)}
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:border-gray-900 dark:focus:border-gray-300 cursor-pointer"
                >
                  <option value="date-desc">Дата: новые первые</option>
                  <option value="date-asc">Дата: старые первые</option>
                  <option value="total-desc">Сумма: по убыванию</option>
                  <option value="total-asc">Сумма: по возрастанию</option>
                </select>
              </div>
            </div>
          </div>

          {/* Orders List */}
          {sortedOrders.length === 0 ? (
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-16 text-center border border-gray-200 dark:border-gray-700 transition-colors">
              <div className="w-24 h-24 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-inbox-line text-5xl text-gray-400 dark:text-gray-500" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">
                Заказы не найдены
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-8">
                По выбранному фильтру заказы отсутствуют
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {sortedOrders.map((order) => {
                const statusConfig = getStatusConfig(order.status);
                const isExpanded = expandedOrder === order.id;

                return (
                  <div
                    key={order.id}
                    className="bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 overflow-hidden transition-all hover:shadow-lg"
                  >
                    {/* Order Header */}
                    <div className="p-6 border-b border-gray-200 dark:border-gray-700">
                      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                              {order.id}
                            </h3>
                            <span
                              className={`px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1 whitespace-nowrap ${statusConfig.color}`}
                            >
                              <i className={`${statusConfig.icon} text-sm`} />
                              {statusConfig.label}
                            </span>
                          </div>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            {formatDate(order.date)} • {order.items.length} товар
                            {order.items.length > 1
                              ? order.items.length > 4
                                ? 'ов'
                                : 'а'
                              : ''}
                          </p>
                        </div>

                        <div className="flex items-center gap-6">
                          <div className="text-right">
                            <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">
                              Итого
                            </p>
                            <p className="text-3xl font-bold text-gray-900 dark:text-white">
                              ${order.total.toFixed(2)}
                            </p>
                          </div>

                          <button
                            onClick={() =>
                              setExpandedOrder(isExpanded ? null : order.id)
                            }
                            className="w-10 h-10 flex items-center justify-center bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors cursor-pointer"
                          >
                            <i
                              className={`ri-arrow-${
                                isExpanded ? 'up' : 'down'
                              }-s-line text-xl text-gray-700 dark:text-gray-300`}
                            />
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Order Details */}
                    {isExpanded && (
                      <div className="p-6 bg-gray-50 dark:bg-gray-900/50">
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                          {/* Items */}
                          <div className="lg:col-span-2">
                            <h4 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
                              Товары
                            </h4>
                            <div className="space-y-4">
                              {order.items.map((item) => (
                                <div
                                  key={item.id}
                                  className="flex gap-4 bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700"
                                >
                                  <div className="w-20 h-20 bg-gray-100 dark:bg-gray-700 rounded-lg overflow-hidden flex-shrink-0">
                                    <img
                                      src={item.thumbnail}
                                      alt={item.title}
                                      className="w-full h-full object-cover object-top"
                                    />
                                  </div>
                                  <div className="flex-1">
                                    <h5 className="font-semibold text-gray-900 dark:text-white mb-1">
                                      {item.title}
                                    </h5>
                                    <p className="text-sm text-gray-600 dark:text-gray-400">
                                      Количество: {item.quantity}
                                    </p>
                                  </div>
                                  <div className="text-right">
                                    <p className="font-bold text-gray-900 dark:text-white">
                                      ${(item.price * item.quantity).toFixed(2)}
                                    </p>
                                    <p className="text-sm text-gray-500 dark:text-gray-400">
                                      ${item.price.toFixed(2)} × {item.quantity}
                                    </p>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Summary and Address */}
                          <div className="space-y-6">
                            {/* Order Summary */}
                            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-gray-200 dark:border-gray-700">
                              <h4 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
                                Детали заказа
                              </h4>
                              <div className="space-y-3">
                                <div className="flex justify-between text-sm">
                                  <span className="text-gray-600 dark:text-gray-400">
                                    Подытог
                                  </span>
                                  <span className="font-semibold text-gray-900 dark:text-white">
                                    ${order.subtotal.toFixed(2)}
                                  </span>
                                </div>

                                {order.discount > 0 && (
                                  <div className="flex justify-between text-sm">
                                    <span className="text-green-600 dark:text-green-400">
                                      Скидка{' '}
                                      {order.promoCode && `(${order.promoCode})`}
                                    </span>
                                    <span className="font-semibold text-green-600 dark:text-green-400">
                                      -${order.discount.toFixed(2)}
                                    </span>
                                  </div>
                                )}

                                <div className="flex justify-between text-sm">
                                  <span className="text-gray-600 dark:text-gray-400">
                                    Доставка
                                  </span>
                                  <span className="font-semibold text-gray-900 dark:text-white">
                                    {order.shipping === 0
                                      ? 'Бесплатно'
                                      : `$${order.shipping.toFixed(2)}`}
                                  </span>
                                </div>

                                <div className="flex justify-between text-sm">
                                  <span className="text-gray-600 dark:text-gray-400">
                                    Налог
                                  </span>
                                  <span className="font-semibold text-gray-900 dark:text-white">
                                    ${order.tax.toFixed(2)}
                                  </span>
                                </div>

                                <div className="border-t border-gray-200 dark:border-gray-700 pt-3">
                                  <div className="flex justify-between">
                                    <span className="font-bold text-gray-900 dark:text-white">
                                      Итого
                                    </span>
                                    <span className="text-xl font-bold text-gray-900 dark:text-white">
                                      ${order.total.toFixed(2)}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>

                            {/* Shipping Address */}
                            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-gray-200 dark:border-gray-700">
                              <h4 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
                                Адрес доставки
                              </h4>
                              <div className="space-y-2 text-sm">
                                <p className="font-semibold text-gray-900 dark:text-white">
                                  {order.shippingAddress.fullName}
                                </p>
                                <p className="text-gray-600 dark:text-gray-400">
                                  {order.shippingAddress.address}
                                </p>
                                <p className="text-gray-600 dark:text-gray-400">
                                  {order.shippingAddress.city},{' '}
                                  {order.shippingAddress.postalCode}
                                </p>
                                <p className="text-gray-600 dark:text-gray-400">
                                  {order.shippingAddress.phone}
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
