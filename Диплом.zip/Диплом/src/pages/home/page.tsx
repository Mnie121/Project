import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';

interface Product {
  id: number;
  title: string;
  price: number;
  thumbnail: string;
  category: string;
  rating: number;
}

export default function HomePage() {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchFeaturedProducts = async () => {
      try {
        setLoading(true);
        const response = await fetch('https://dummyjson.com/products?limit=8');
        if (!response.ok) throw new Error('Failed to fetch products');
        const data = await response.json();
        setFeaturedProducts(data.products);
      } catch (err) {
        setError('Не удалось загрузить товары. Пожалуйста, попробуйте позже.');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchFeaturedProducts();
  }, []);

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <Header />

      <section className="relative h-screen flex items-center justify-center overflow-hidden bg-gray-50 dark:bg-gray-800">
        <div className="absolute inset-0">
          <img
            src="https://readdy.ai/api/search-image?query=A%20minimalist%20modern%20shopping%20scene%20with%20clean%20white%20surfaces%20and%20soft%20natural%20lighting%2C%20featuring%20elegant%20product%20displays%20in%20a%20bright%20contemporary%20retail%20environment%20with%20subtle%20shadows%20and%20a%20calm%20professional%20atmosphere&width=1920&height=1080&seq=home-hero-bg-001&orientation=landscape"
            alt="Hero background"
            className="w-full h-full object-cover object-top opacity-20 dark:opacity-10"
          />
        </div>
        
        <div className="relative z-10 max-w-[1400px] mx-auto px-8 w-full">
          <div className="flex flex-col items-center text-center">
            <div>
              <div className="inline-flex items-center gap-2 bg-white dark:bg-gray-800 rounded-full px-4 py-2 mb-8 shadow-lg border border-gray-200 dark:border-gray-700">
                <span className="w-2 h-2 bg-gray-900 dark:bg-gray-100 rounded-full animate-pulse"></span>
                <span className="text-sm font-medium text-gray-900 dark:text-gray-100">Новинки 2025</span>
              </div>

              <h1 className="text-6xl lg:text-7xl font-extrabold text-gray-900 dark:text-white leading-tight mb-8">
                Откройте для себя качественные товары
              </h1>

              <p className="text-lg text-gray-600 dark:text-gray-300 mb-10 max-w-xl mx-auto leading-relaxed">
                Покупайте последние тренды и вечную классику по непревзойдённым ценам. Ваш идеальный товар всего в одном клике.
              </p>

              <div className="flex items-center justify-center gap-6">
                <Link
                  to="/catalog"
                  className="bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900 px-8 py-4 rounded-lg font-medium hover:bg-gray-800 dark:hover:bg-gray-200 transition-all flex items-center gap-2 whitespace-nowrap shadow-lg"
                >
                  Купить сейчас
                  <i className="ri-arrow-right-line"></i>
                </Link>
                <Link
                  to="/about"
                  className="text-gray-900 dark:text-gray-100 font-medium hover:underline whitespace-nowrap"
                >
                  Подробнее
                </Link>
              </div>
            </div>

            <div className="flex items-center gap-8 mt-12">
              <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-xl border border-gray-200 dark:border-gray-700">
                <p className="text-3xl font-bold text-gray-900 dark:text-white">500+</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">Товаров</p>
              </div>
              <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-xl border border-gray-200 dark:border-gray-700">
                <p className="text-3xl font-bold text-gray-900 dark:text-white">50K+</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">Клиентов</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="max-w-[1400px] mx-auto px-8">
          <div className="flex items-center justify-between mb-12">
            <div>
              <div className="inline-block bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900 text-xs font-bold px-3 py-1 rounded-full mb-4">
                ПОПУЛЯРНОЕ
              </div>
              <h2 className="text-5xl font-bold text-gray-900 dark:text-white">
                Избранные товары
              </h2>
              <p className="text-gray-600 dark:text-gray-400 mt-2">Тщательно отобранные бестселлеры</p>
            </div>
          </div>

          {loading && (
            <div className="flex justify-center items-center py-20">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900 dark:border-gray-100"></div>
            </div>
          )}

          {error && (
            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-400 px-6 py-4 rounded-lg">
              {error}
            </div>
          )}

          {!loading && !error && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8" data-product-shop>
              {featuredProducts.map((product) => (
                <Link
                  key={product.id}
                  to={`/product/${product.id}`}
                  className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-2 group border border-gray-200 dark:border-gray-700"
                >
                  <div className="aspect-square overflow-hidden bg-gray-100 dark:bg-gray-700">
                    <img
                      src={product.thumbnail}
                      alt={product.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                  </div>
                  <div className="p-6">
                    <p className="text-xs text-gray-500 dark:text-gray-400 uppercase mb-2">{product.category}</p>
                    <h3 className="font-semibold text-gray-900 dark:text-white mb-3 line-clamp-2 min-h-[3rem]">
                      {product.title}
                    </h3>
                    <div className="flex items-center justify-between">
                      <p className="text-2xl font-bold text-gray-900 dark:text-white">${product.price}</p>
                      <div className="flex items-center gap-1">
                        <i className="ri-star-fill text-yellow-400 text-sm"></i>
                        <span className="text-sm text-gray-600 dark:text-gray-400">{product.rating}</span>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}

          <div className="text-center mt-12">
            <Link
              to="/catalog"
              className="inline-block bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900 px-8 py-4 rounded-lg font-medium hover:bg-gray-800 dark:hover:bg-gray-200 transition-colors whitespace-nowrap"
            >
              Смотреть все товары
            </Link>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-[1400px] mx-auto px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <div className="inline-block border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 text-xs font-medium px-3 py-1 rounded-full mb-8">
                КТО МЫ
              </div>
              <h2 className="text-5xl font-bold mb-6">
                <span className="text-gray-900 dark:text-white">Ваш надёжный</span>
                <br />
                <span className="text-gray-700 dark:text-gray-300">партнёр в покупках</span>
              </h2>
              <p className="text-gray-600 dark:text-gray-400 text-lg leading-relaxed mb-8">
                KiriStore — ваш главный магазин качественных товаров во всех категориях. 
                Мы отбираем лучшие товары от ведущих брендов, гарантируя качество, 
                инновации и исключительную ценность для наших клиентов по всему миру.
              </p>
              <Link to="/about" className="text-gray-900 dark:text-gray-100 font-medium hover:underline">
                Узнать больше о нас →
              </Link>
            </div>

            <div className="relative">
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-white dark:bg-gray-700 rounded-lg p-8 shadow-lg border border-gray-200 dark:border-gray-600">
                  <i className="ri-shield-check-line text-5xl text-gray-900 dark:text-gray-100 mb-4"></i>
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Гарантия качества</h3>
                  <p className="text-gray-600 dark:text-gray-400 text-sm">100% оригинальные товары с гарантией</p>
                </div>
                <div className="bg-white dark:bg-gray-700 rounded-lg p-8 shadow-lg mt-8 border border-gray-200 dark:border-gray-600">
                  <i className="ri-truck-line text-5xl text-gray-900 dark:text-gray-100 mb-4"></i>
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Быстрая доставка</h3>
                  <p className="text-gray-600 dark:text-gray-400 text-sm">Бесплатная доставка при заказе от $50</p>
                </div>
                <div className="bg-white dark:bg-gray-700 rounded-lg p-8 shadow-lg border border-gray-200 dark:border-gray-600">
                  <i className="ri-customer-service-2-line text-5xl text-gray-900 dark:text-gray-100 mb-4"></i>
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Поддержка 24/7</h3>
                  <p className="text-gray-600 dark:text-gray-400 text-sm">Всегда готовы помочь вам</p>
                </div>
                <div className="bg-white dark:bg-gray-700 rounded-lg p-8 shadow-lg mt-8 border border-gray-200 dark:border-gray-600">
                  <i className="ri-secure-payment-line text-5xl text-gray-900 dark:text-gray-100 mb-4"></i>
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Безопасная оплата</h3>
                  <p className="text-gray-600 dark:text-gray-400 text-sm">Ваши данные всегда защищены</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
