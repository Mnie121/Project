import { Link } from 'react-router-dom';
import Header from '../components/feature/Header';
import Footer from '../components/feature/Footer';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-950 transition-colors flex flex-col">
      <Header />
      <main className="flex-1 flex items-center justify-center px-8 pt-[72px]">
        <div className="text-center">
          <h1 className="text-9xl font-bold text-gray-900 dark:text-white mb-4">404</h1>
          <p className="text-2xl text-gray-600 dark:text-gray-400 mb-8">
            Страница не найдена
          </p>
          <Link
            to="/"
            className="inline-block px-8 py-3 bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900 rounded-lg font-medium hover:bg-gray-800 dark:hover:bg-gray-200 transition-colors whitespace-nowrap"
          >
            Вернуться на главную
          </Link>
        </div>
      </main>
      <Footer />
    </div>
  );
}
