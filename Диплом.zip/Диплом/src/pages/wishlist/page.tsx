
import { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';

interface WishlistItem {
  id: number;
  title: string;
  price: number;
  thumbnail: string;
  category: string;
  rating: number;
}

type SortOption = 'default' | 'price-asc' | 'price-desc';

export default function WishlistPage() {
  const [wishlist, setWishlist] = useState<WishlistItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState<SortOption>('default');
  const [showNotification, setShowNotification] = useState(false);
  const [notificationMsg, setNotificationMsg] = useState('');

  useEffect(() => {
    loadWishlist();
    const handler = () => loadWishlist();
    window.addEventListener('wishlistUpdated', handler);
    return () => window.removeEventListener('wishlistUpdated', handler);
  }, []);

  const loadWishlist = () => {
    const saved = JSON.parse(localStorage.getItem('wishlist') || '[]') as WishlistItem[];
    setWishlist(saved);
  };

  const categories = useMemo(() => {
    const cats = Array.from(new Set(wishlist.map((item) => item.category)));
    return cats.sort();
  }, [wishlist]);

  const filteredAndSorted = useMemo(() => {
    let result = [...wishlist];

    if (selectedCategory !== 'all') {
      result = result.filter((item) => item.category === selectedCategory);
    }

    if (sortBy === 'price-asc') {
      result.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-desc') {
      result.sort((a, b) => b.price - a.price);
    }

    return result;
  }, [wishlist, selectedCategory, sortBy]);

  const removeFromWishlist = (id: number) => {
    const updated = wishlist.filter((item) => item.id !== id);
    setWishlist(updated);
    localStorage.setItem('wishlist', JSON.stringify(updated));
    window.dispatchEvent(new Event('wishlistUpdated'));
    showNotify('Товар удалён из желаемого');
  };

  const addToCart = (item: WishlistItem) => {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const existing = cart.find((c: any) => c.id === item.id);
    if (existing) {
      existing.quantity += 1;
    } else {
      cart.push({
        id: item.id,
        title: item.title,
        price: item.price,
        thumbnail: item.thumbnail,
        quantity: 1,
      });
    }
    localStorage.setItem('cart', JSON.stringify(cart));
    window.dispatchEvent(new Event('cartUpdated'));
    showNotify('Товар добавлен в корзину');
  };

  const clearWishlist = () => {
    setWishlist([]);
    localStorage.setItem('wishlist', JSON.stringify([]));
    window.dispatchEvent(new Event('wishlistUpdated'));
    showNotify('Список желаемого очищен');
  };

  const showNotify = (msg: string) => {
    setNotificationMsg(msg);
    setShowNotification(true);
    setTimeout(() => setShowNotification(false), 3000);
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <Header />

      {showNotification && (
        <div className="fixed top-24 right-8 bg-green-500 text-white px-6 py-4 rounded-lg shadow-xl z-50 animate-fade-in">
          <div className="flex items-center gap-3">
            <i className="ri-checkbox-circle-line text-2xl"></i>
            <span className="font-medium">{notificationMsg}</span>
          </div>
        </div>
      )}

      <main className="pt-24 pb-20">
        <div className="max-w-[1400px] mx-auto px-8">
          <div className="mb-12">
            <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400 mb-6">
              <Link to="/" className="hover:text-gray-900 dark:hover:text-gray-200">Главная</Link>
              <i className="ri-arrow-right-s-line"></i>
              <span className="text-gray-900 dark:text-white">Желаемое</span>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-5xl font-bold text-gray-900 dark:text-white mb-4">Желаемое</h1>
                <p className="text-gray-600 dark:text-gray-400">
                  {wishlist.length > 0
                    ? `${wishlist.length} ${wishlist.length === 1 ? 'товар' : wishlist.length < 5 ? 'товара' : 'товаров'} в вашем списке`
                    : 'Ваш список желаемого пуст'}
                </p>
              </div>
              {wishlist.length > 0 && (
                <button
                  onClick={clearWishlist}
                  className="flex items-center gap-2 px-5 py-3 rounded-lg border border-red-300 dark:border-red-700 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-delete-bin-line text-lg"></i>
                  Очистить всё
                </button>
              )}
            </div>
          </div>

          {wishlist.length > 0 && (
            <div className="bg-gray-50 dark:bg-gray-800 rounded-2xl shadow-sm p-6 mb-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:border-gray-900 dark:focus:border-gray-400 text-sm cursor-pointer bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                >
                  <option value="all">Все категории</option>
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat.charAt(0).toUpperCase() + cat.slice(1)}
                    </option>
                  ))}
                </select>

                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as SortOption)}
                  className="px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:border-gray-900 dark:focus:border-gray-400 text-sm cursor-pointer bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                >
                  <option value="default">Сортировка по цене</option>
                  <option value="price-asc">Цена: по возрастанию</option>
                  <option value="price-desc">Цена: по убыванию</option>
                </select>
              </div>
            </div>
          )}

          {wishlist.length === 0 ? (
            <div className="text-center py-32">
              <div className="w-24 h-24 flex items-center justify-center mx-auto mb-6 bg-gray-100 dark:bg-gray-800 rounded-full">
                <i className="ri-heart-line text-5xl text-gray-300 dark:text-gray-600"></i>
              </div>
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">Список пуст</h2>
              <p className="text-gray-500 dark:text-gray-400 mb-8 max-w-md mx-auto">
                Добавляйте понравившиеся товары в список желаемого, чтобы не потерять их
              </p>
              <Link
                to="/catalog"
                className="inline-flex items-center gap-2 bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900 px-8 py-4 rounded-lg font-medium hover:bg-gray-800 dark:hover:bg-gray-200 transition-colors whitespace-nowrap"
              >
                Перейти в каталог
                <i className="ri-arrow-right-line"></i>
              </Link>
            </div>
          ) : (
            <>
              {filteredAndSorted.length === 0 ? (
                <div className="text-center py-20">
                  <i className="ri-search-line text-6xl text-gray-300 dark:text-gray-600 mb-4"></i>
                  <p className="text-xl text-gray-600 dark:text-gray-400">Нет товаров в выбранной категории</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8" data-product-shop>
                  {filteredAndSorted.map((item) => (
                    <div key={item.id} className="relative group">
                      <Link
                        to={`/product/${item.id}`}
                        className="block bg-white dark:bg-gray-800 rounded-2xl overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border border-gray-200 dark:border-gray-700"
                      >
                        <div className="aspect-square overflow-hidden bg-gray-100 dark:bg-gray-700">
                          <img
                            src={item.thumbnail}
                            alt={item.title}
                            title={item.title}
                            className="w-full h-full object-cover object-top group-hover:scale-110 transition-transform duration-300"
                          />
                        </div>
                        <div className="p-6">
                          <p className="text-xs text-gray-500 dark:text-gray-400 uppercase mb-2">{item.category}</p>
                          <h3 className="font-semibold text-gray-900 dark:text-white mb-3 line-clamp-2 min-h-[3rem]">
                            {item.title}
                          </h3>
                          <div className="flex items-center justify-between">
                            <p className="text-2xl font-bold text-gray-900 dark:text-white">${item.price}</p>
                            <div className="flex items-center gap-1">
                              <i className="ri-star-fill text-yellow-400 text-sm"></i>
                              <span className="text-sm text-gray-600 dark:text-gray-400">{item.rating}</span>
                            </div>
                          </div>
                        </div>
                      </Link>

                      <div className="absolute top-4 right-4 flex flex-col gap-2">
                        <button
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            removeFromWishlist(item.id);
                          }}
                          className="w-10 h-10 flex items-center justify-center rounded-full bg-white dark:bg-gray-800 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/30 shadow-lg cursor-pointer transition-all"
                          title="Удалить из желаемого"
                        >
                          <i className="ri-heart-fill text-lg"></i>
                        </button>
                        <button
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            addToCart(item);
                          }}
                          className="w-10 h-10 flex items-center justify-center rounded-full bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900 hover:bg-gray-800 dark:hover:bg-gray-200 shadow-lg cursor-pointer transition-all"
                          title="Добавить в корзину"
                        >
                          <i className="ri-shopping-cart-line text-lg"></i>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
