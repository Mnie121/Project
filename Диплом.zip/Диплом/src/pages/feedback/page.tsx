import { useState, useRef, useEffect } from 'react';
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';
import { feedbackList as initialFeedback } from '../../mocks/feedbackData';

interface FeedbackItem {
  id: number;
  name: string;
  avatar: string;
  rating: number;
  date: string;
  title: string;
  comment: string;
}

export default function FeedbackPage() {
  const [feedbacks, setFeedbacks] = useState<FeedbackItem[]>(() => {
    const saved = localStorage.getItem('kiristore-feedbacks');
    return saved ? JSON.parse(saved) : initialFeedback;
  });
  const [formRating, setFormRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [highlightId, setHighlightId] = useState<number | null>(null);
  const listTopRef = useRef<HTMLDivElement>(null);
  const [showSuccess, setShowSuccess] = useState(false);

  useEffect(() => {
    if (highlightId !== null) {
      const timer = setTimeout(() => setHighlightId(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [highlightId]);

  const validateForm = (form: HTMLFormElement): boolean => {
    const newErrors: Record<string, string> = {};
    const name = (form.elements.namedItem('name') as HTMLInputElement).value.trim();
    const title = (form.elements.namedItem('title') as HTMLInputElement).value.trim();
    const comment = (form.elements.namedItem('comment') as HTMLTextAreaElement).value.trim();

    if (!name) newErrors.name = 'Имя обязательно';
    if (!title) newErrors.title = 'Заголовок обязателен';
    if (!comment) newErrors.comment = 'Отзыв обязателен';
    if (comment.length > 500) newErrors.comment = 'Отзыв должен быть не более 500 символов';
    if (formRating === 0) newErrors.rating = 'Пожалуйста, выберите рейтинг';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
  
    if (!validateForm(form)) return;
  
    setIsSubmitting(true);
  
    const nameVal = (form.elements.namedItem('name') as HTMLInputElement).value.trim();
    const titleVal = (form.elements.namedItem('title') as HTMLInputElement).value.trim();
    const commentVal = (form.elements.namedItem('comment') as HTMLTextAreaElement).value.trim();
  
    const now = new Date();
    const months = ['янв','фев','мар','апр','мая','июн','июл','авг','сен','окт','ноя','дек'];
    const dateStr = `${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}`;
    const newId = Date.now();
  
    const newFeedback: FeedbackItem = {
      id: newId,
      name: nameVal,
      avatar: 'https://ichef.bbci.co.uk/ace/ws/640/cpsprodpb/1352A/production/_103464197_luke-watkin.gif.webp',
      rating: formRating,
      date: dateStr,
      title: titleVal,
      comment: commentVal,
    };
  
    // Добавляем отзыв
    setFeedbacks(prev => {
      const updated = [newFeedback, ...prev];
      localStorage.setItem('kiristore-feedbacks', JSON.stringify(updated));
      return updated;
    });
    setHighlightId(newId);
  
    // Показываем уведомление
    setShowSuccess(true);
  
    // Очистка формы
    form.reset();
    setFormRating(0);
    setErrors({});
  
    // Скролл к отзыву
    setTimeout(() => {
      listTopRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  
    // Скрыть уведомление
    setTimeout(() => {
      setShowSuccess(false);
    }, 3000);
  
    setIsSubmitting(false);
  };

  const renderStars = (rating: number) =>
    Array.from({ length: 5 }, (_, i) => (
      <i
        key={i}
        className={`${i < rating ? 'ri-star-fill text-amber-400' : 'ri-star-line text-gray-300 dark:text-gray-600'} text-sm`}
      ></i>
    ));

  const averageRating = feedbacks.length > 0
    ? (feedbacks.reduce((sum, f) => sum + f.rating, 0) / feedbacks.length).toFixed(1)
    : '0';

  const ratingDistribution = [5,4,3,2,1].map(star => ({
    star,
    count: feedbacks.filter(f => f.rating === star).length,
    percentage: feedbacks.length > 0 ? (feedbacks.filter(f => f.rating === star).length / feedbacks.length) * 100 : 0,
  }));

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <Header />
      {showSuccess && (
      <div className="fixed top-24 right-8 bg-green-500 text-white px-6 py-4 rounded-lg shadow-xl z-50 animate-fade-in">
        <div className="flex items-center gap-3">
          <i className="ri-checkbox-circle-line text-2xl"></i>
          <span className="font-medium">Отзыв успешно отправлен!</span>
        </div>
      </div>
    )}

      <main className="pt-[72px]">
        <section className="bg-gray-50 dark:bg-gray-800 py-16">
          <div className="max-w-[1100px] mx-auto px-8">
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-3">Отзывы клиентов</h1>
            <p className="text-gray-600 dark:text-gray-400 text-base">Посмотрите, что говорят наши клиенты, и поделитесь своим опытом</p>
          </div>
        </section>

        <div className="max-w-[1100px] mx-auto px-8 py-16">
          {/* Rating Summary */}
          <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-8 mb-12">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div className="flex flex-col items-center justify-center">
                <p className="text-6xl font-bold text-gray-900 dark:text-white mb-2">{averageRating}</p>
                <div className="flex gap-1 mb-2">{renderStars(Math.round(Number(averageRating)))}</div>
                <p className="text-sm text-gray-500 dark:text-gray-400">На основе {feedbacks.length} отзывов</p>
              </div>
              <div className="space-y-3">
                {ratingDistribution.map(item => (
                  <div key={item.star} className="flex items-center gap-3">
                    <span className="text-sm text-gray-600 dark:text-gray-400 w-12 whitespace-nowrap">{item.star} звёзд</span>
                    <div className="flex-1 h-2.5 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
                      <div className="h-full bg-amber-400 rounded-full transition-all" style={{ width: `${item.percentage}%` }}></div>
                    </div>
                    <span className="text-sm text-gray-500 dark:text-gray-400 w-8 text-right">{item.count}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
            {/* Feedback List */}
            <div className="lg:col-span-3">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Все отзывы</h2>
              <div ref={listTopRef} className="space-y-5">
                {feedbacks.map(fb => (
                  <div
                    key={fb.id}
                    className={`bg-white dark:bg-gray-800 rounded-lg border p-6 transition-all duration-700 ${
                      highlightId === fb.id
                        ? 'border-emerald-400 dark:border-emerald-500 shadow-md shadow-emerald-100 dark:shadow-emerald-900/20 ring-1 ring-emerald-200 dark:ring-emerald-700'
                        : 'border-gray-200 dark:border-gray-700'
                    }`}
                  >
                    {highlightId === fb.id && (
                      <div className="flex items-center gap-1.5 mb-3">
                        <div className="w-4 h-4 flex items-center justify-center">
                          <i className="ri-sparkling-line text-emerald-500 text-sm"></i>
                        </div>
                        <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400">Ваш отзыв</span>
                      </div>
                    )}
                    <div className="flex items-start gap-4">
                      <div className="w-11 h-11 rounded-full overflow-hidden flex-shrink-0">
                        <img src={fb.avatar} alt={fb.name} className="w-full h-full object-cover object-top" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="text-sm font-semibold text-gray-900 dark:text-white">{fb.name}</h4>
                          <span className="text-xs text-gray-400 dark:text-gray-500 whitespace-nowrap">{fb.date}</span>
                        </div>
                        <div className="flex gap-0.5 mb-3">{renderStars(fb.rating)}</div>
                        <h5 className="text-sm font-semibold text-gray-900 dark:text-white mb-1.5">{fb.title}</h5>
                        <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">{fb.comment}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Feedback Form */}
            <div className="lg:col-span-2">
              <div className="sticky top-[96px]">
                <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Написать отзыв</h2>
                <form onSubmit={handleSubmit} className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6 space-y-5">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Ваше имя</label>
                    <input type="text" name="name" placeholder="Введите ваше имя" className="w-full px-4 py-2.5 rounded-md bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white text-sm" />
                    {errors.name && <p className="text-xs text-red-500 mt-1">{errors.name}</p>}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Рейтинг</label>
                    <div className="flex gap-1">
                      {[1,2,3,4,5].map(star => (
                        <button key={star} type="button" onClick={() => setFormRating(star)} onMouseEnter={() => setHoverRating(star)} onMouseLeave={() => setHoverRating(0)} className="cursor-pointer p-0.5">
                          <i className={`text-2xl ${star <= (hoverRating || formRating) ? 'ri-star-fill text-amber-400' : 'ri-star-line text-gray-300 dark:text-gray-600'}`}></i>
                        </button>
                      ))}
                    </div>
                    {errors.rating && <p className="text-xs text-red-500 mt-1">{errors.rating}</p>}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Заголовок отзыва</label>
                    <input type="text" name="title" placeholder="Кратко опишите ваш опыт" className="w-full px-4 py-2.5 rounded-md bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white text-sm" />
                    {errors.title && <p className="text-xs text-red-500 mt-1">{errors.title}</p>}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Ваш отзыв</label>
                    <textarea name="comment" rows={4} maxLength={500} placeholder="Расскажите о вашем опыте..." className="w-full px-4 py-2.5 rounded-md bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-white text-sm resize-none"></textarea>
                    {errors.comment && <p className="text-xs text-red-500 mt-1">{errors.comment}</p>}
                  </div>

                  <button type="submit" disabled={isSubmitting} className="w-full bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900 py-3 rounded-md text-sm font-medium disabled:opacity-50">{isSubmitting ? 'Отправка...' : 'Отправить отзыв'}</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}