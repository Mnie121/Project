import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <Header />

      <main className="pt-24 pb-20">
        <section className="py-20 bg-gray-50 dark:bg-gray-800">
          <div className="max-w-[1000px] mx-auto px-8 text-center">
            <h1 className="text-6xl font-bold text-gray-900 dark:text-white mb-8">
              О KiriStore
            </h1>
            <p className="text-xl text-gray-700 dark:text-gray-300 leading-relaxed mb-6">
              Добро пожаловать в KiriStore — ваш главный магазин качественных товаров во всех категориях. 
              С момента основания мы стремимся предлагать лучший выбор покупателям, 
              которые ценят качество, разнообразие и исключительный сервис.
            </p>
            <p className="text-lg text-gray-600 dark:text-gray-400 leading-relaxed">
              Мы верим, что покупки должны быть доступными, выгодными и приятными. Наш тщательно отобранный 
              ассортимент включает товары от проверенных брендов со всего мира, гарантируя качество и надёжность 
              при каждой покупке.
            </p>
          </div>
        </section>

        <section className="py-20 bg-white dark:bg-gray-900">
          <div className="max-w-[1400px] mx-auto px-8">
            <div className="text-center mb-16">
              <h2 className="text-5xl font-bold text-gray-900 dark:text-white mb-4">Почему выбирают нас</h2>
              <p className="text-gray-600 dark:text-gray-400 text-lg">Что отличает KiriStore от остальных</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-8 text-center hover:shadow-xl transition-shadow border border-gray-200 dark:border-gray-700">
                <div className="w-20 h-20 bg-gray-900 dark:bg-gray-100 rounded-lg flex items-center justify-center mx-auto mb-6">
                  <i className="ri-shield-check-line text-4xl text-white dark:text-gray-900"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Гарантия качества</h3>
                <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                  Каждый товар на 100% оригинален и поставляется с полной гарантией. Мы отвечаем за 
                  всё, что продаём, нашей гарантией качества.
                </p>
              </div>

              <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-8 text-center hover:shadow-xl transition-shadow border border-gray-200 dark:border-gray-700">
                <div className="w-20 h-20 bg-gray-900 dark:bg-gray-100 rounded-lg flex items-center justify-center mx-auto mb-6">
                  <i className="ri-truck-line text-4xl text-white dark:text-gray-900"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Быстрая доставка</h3>
                <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                  Бесплатная доставка при заказе от $50. Большинство заказов отправляются в течение 24 часов и прибывают 
                  к вашей двери за 2-5 рабочих дней.
                </p>
              </div>

              <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-8 text-center hover:shadow-xl transition-shadow border border-gray-200 dark:border-gray-700">
                <div className="w-20 h-20 bg-gray-900 dark:bg-gray-100 rounded-lg flex items-center justify-center mx-auto mb-6">
                  <i className="ri-customer-service-2-line text-4xl text-white dark:text-gray-900"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Поддержка 24/7</h3>
                <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                  Наша преданная команда поддержки всегда готова помочь. Свяжитесь с нами в любое время по телефону, email 
                  или в онлайн-чате.
                </p>
              </div>

              <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-8 text-center hover:shadow-xl transition-shadow border border-gray-200 dark:border-gray-700">
                <div className="w-20 h-20 bg-gray-900 dark:bg-gray-100 rounded-lg flex items-center justify-center mx-auto mb-6">
                  <i className="ri-secure-payment-line text-4xl text-white dark:text-gray-900"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Безопасная оплата</h3>
                <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                  Ваши данные защищены ведущим в отрасли шифрованием. Покупайте с уверенностью, зная, 
                  что ваша информация в безопасности.
                </p>
              </div>

              <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-8 text-center hover:shadow-xl transition-shadow border border-gray-200 dark:border-gray-700">
                <div className="w-20 h-20 bg-gray-900 dark:bg-gray-100 rounded-lg flex items-center justify-center mx-auto mb-6">
                  <i className="ri-price-tag-3-line text-4xl text-white dark:text-gray-900"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Лучшие цены</h3>
                <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                  Мы предлагаем конкурентные цены на все товары. Плюс, наслаждайтесь эксклюзивными предложениями и скидками 
                  для наших постоянных клиентов.
                </p>
              </div>

              <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-8 text-center hover:shadow-xl transition-shadow border border-gray-200 dark:border-gray-700">
                <div className="w-20 h-20 bg-gray-900 dark:bg-gray-100 rounded-lg flex items-center justify-center mx-auto mb-6">
                  <i className="ri-arrow-go-back-line text-4xl text-white dark:text-gray-900"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Лёгкий возврат</h3>
                <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                  Не удовлетворены? Нет проблем. Мы предлагаем беспроблемный возврат в течение 30 дней с момента покупки, 
                  без лишних вопросов.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-gray-50 dark:bg-gray-800">
          <div className="max-w-[1400px] mx-auto px-8">
            <div className="text-center mb-16">
              <h2 className="text-5xl font-bold text-gray-900 dark:text-white mb-4">Свяжитесь с нами</h2>
              <p className="text-gray-600 dark:text-gray-400 text-lg">Мы будем рады услышать вас</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              <div className="text-center">
                <div className="w-16 h-16 bg-gray-900 dark:bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <i className="ri-phone-line text-3xl text-white dark:text-gray-900"></i>
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">Телефон</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-2">Звоните в любое время</p>
                <a href="tel:+15551234567" className="text-gray-900 dark:text-gray-100 hover:underline transition-colors">
                +7 778 123 4567
                </a>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-gray-900 dark:bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <i className="ri-mail-line text-3xl text-white dark:text-gray-900"></i>
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">Email</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-2">Отправьте нам сообщение</p>
                <a
                  href="mailto:support@kiristore.com"
                  className="text-gray-900 dark:text-gray-100 hover:underline transition-colors"
                >
                  support@kiristore.com
                </a>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-gray-900 dark:bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <i className="ri-map-pin-line text-3xl text-white dark:text-gray-900"></i>
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">Адрес</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-2">Посетите наш магазин</p>
                <p className="text-gray-900 dark:text-gray-100">ул. Кабдолова 1/4,<br />Алматы 050000</p>
              </div>
            </div>

            <div className="mt-16 text-center">
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Подписывайтесь на нас</h3>
              <div className="flex justify-center gap-6">
                <a
                  href="https://www.facebook.com/p/Kiristore-100083013228369/"
                  className="w-12 h-12 bg-gray-200 dark:bg-gray-700 hover:bg-gray-900 dark:hover:bg-gray-100 text-gray-900 dark:text-gray-100 hover:text-white dark:hover:text-gray-900 rounded-full flex items-center justify-center transition-colors"
                >
                  <i className="ri-facebook-fill text-2xl"></i>
                </a>
                <a
                  href="https://x.com/Store"
                  className="w-12 h-12 bg-gray-200 dark:bg-gray-700 hover:bg-gray-900 dark:hover:bg-gray-100 text-gray-900 dark:text-gray-100 hover:text-white dark:hover:text-gray-900 rounded-full flex items-center justify-center transition-colors"
                >
                  <i className="ri-twitter-x-fill text-2xl"></i>
                </a>
                <a
                  href="https://www.instagram.com/kiri_stores/"
                  className="w-12 h-12 bg-gray-200 dark:bg-gray-700 hover:bg-gray-900 dark:hover:bg-gray-100 text-gray-900 dark:text-gray-100 hover:text-white dark:hover:text-gray-900 rounded-full flex items-center justify-center transition-colors"
                >
                  <i className="ri-instagram-line text-2xl"></i>
                </a>
                <a
                  href="https://www.linkedin.com/company/storeprojects"
                  className="w-12 h-12 bg-gray-200 dark:bg-gray-700 hover:bg-gray-900 dark:hover:bg-gray-100 text-gray-900 dark:text-gray-100 hover:text-white dark:hover:text-gray-900 rounded-full flex items-center justify-center transition-colors"
                >
                  <i className="ri-linkedin-fill text-2xl"></i>
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
