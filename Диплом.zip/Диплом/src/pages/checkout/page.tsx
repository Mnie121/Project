import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';

interface CartItem {
  id: number;
  title: string;
  price: number;
  thumbnail: string;
  quantity: number;
}

interface FormData {
  fullName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  postalCode: string;
}

interface FormErrors {
  fullName?: string;
  email?: string;
  phone?: string;
  address?: string;
  city?: string;
  postalCode?: string;
}

interface AppliedPromo {
  code: string;
  discount: number;
}

export default function CheckoutPage() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [appliedPromo, setAppliedPromo] = useState<AppliedPromo | null>(null);
  const [formData, setFormData] = useState<FormData>({
    fullName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    postalCode: '',
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [loading, setLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    if (cart.length === 0) {
      navigate('/cart');
    }
    setCartItems(cart);
    
    const saved = localStorage.getItem('appliedPromo');
    if (saved) {
      setAppliedPromo(JSON.parse(saved));
    }
  }, [navigate]);

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};

    if (!formData.fullName.trim()) {
      newErrors.fullName = 'Полное имя обязательно';
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim()) {
      newErrors.email = 'Email обязателен';
    } else if (!emailRegex.test(formData.email)) {
      newErrors.email = 'Неверный формат email';
    }

    const phoneRegex = /^[\d\s\-\+\(\)]+$/;
    if (!formData.phone.trim()) {
      newErrors.phone = 'Номер телефона обязателен';
    } else if (!phoneRegex.test(formData.phone)) {
      newErrors.phone = 'Неверный номер телефона';
    }

    if (!formData.address.trim()) {
      newErrors.address = 'Адрес обязателен';
    }

    if (!formData.city.trim()) {
      newErrors.city = 'Город обязателен';
    }

    if (!formData.postalCode.trim()) {
      newErrors.postalCode = 'Почтовый индекс обязателен';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name as keyof FormErrors]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setLoading(true);

    try {
      const orderData = {
        id: `ORD-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 1000)).padStart(3, '0')}`,
        date: new Date().toISOString().split('T')[0],
        status: 'processing' as const,
        items: cartItems,
        subtotal: subtotal,
        discount: discount,
        promoCode: appliedPromo?.code,
        shipping: shipping,
        tax: tax,
        total: total,
        shippingAddress: {
          fullName: formData.fullName,
          address: formData.address,
          city: formData.city,
          postalCode: formData.postalCode,
          phone: formData.phone
        }
      };

      const response = await fetch('https://jsonplaceholder.typicode.com/posts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(orderData),
      });

      if (!response.ok) throw new Error('Order submission failed');

      // Save order to localStorage
      const existingOrders = JSON.parse(localStorage.getItem('userOrders') || '[]');
      existingOrders.unshift(orderData);
      localStorage.setItem('userOrders', JSON.stringify(existingOrders));

      localStorage.removeItem('cart');
      localStorage.removeItem('appliedPromo');
      window.dispatchEvent(new Event('cartUpdated'));

      setShowSuccess(true);
      setTimeout(() => {
        navigate('/orders');
      }, 3000);
    } catch (error) {
      console.error('Order error:', error);
      alert('Не удалось оформить заказ. Попробуйте снова.');
    } finally {
      setLoading(false);
    }
  };

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const discount = appliedPromo ? appliedPromo.discount : 0;
  const subtotalAfterDiscount = subtotal - discount;
  const shipping = subtotalAfterDiscount > 50 ? 0 : 10;
  const tax = subtotalAfterDiscount * 0.1;
  const total = subtotalAfterDiscount + shipping + tax;

  if (showSuccess) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center transition-colors">
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-12 shadow-xl text-center max-w-md border border-gray-200 dark:border-gray-700">
          <div className="w-20 h-20 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="ri-checkbox-circle-line text-5xl text-green-600 dark:text-green-400"></i>
          </div>
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Заказ успешно оформлен!</h2>
          <p className="text-gray-600 dark:text-gray-400 mb-8">
            Спасибо за покупку. Вы получите письмо с подтверждением в ближайшее время.
          </p>
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 dark:border-white mx-auto"></div>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-4">Перенаправление на страницу заказов...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      <Header />

      <main className="pt-24 pb-20">
        <div className="max-w-[1400px] mx-auto px-8">
          <h1 className="text-5xl font-bold text-gray-900 dark:text-white mb-12">Оформление заказа</h1>

          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-8">
                <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-sm border border-gray-200 dark:border-gray-700 transition-colors">
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Информация о доставке</h2>

                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Полное имя *
                      </label>
                      <input
                        type="text"
                        name="fullName"
                        value={formData.fullName}
                        onChange={handleInputChange}
                        className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:border-gray-900 dark:focus:border-gray-300 bg-white dark:bg-gray-700 text-gray-900 dark:text-white transition-colors ${
                          errors.fullName ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'
                        }`}
                        placeholder="Иван Иванов"
                      />
                      {errors.fullName && (
                        <p className="text-red-500 dark:text-red-400 text-sm mt-1 flex items-center gap-1">
                          <i className="ri-error-warning-line"></i>
                          {errors.fullName}
                        </p>
                      )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Email *
                        </label>
                        <input
                          type="email"
                          name="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:border-gray-900 dark:focus:border-gray-300 bg-white dark:bg-gray-700 text-gray-900 dark:text-white transition-colors ${
                            errors.email ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'
                          }`}
                          placeholder="ivan@example.com"
                        />
                        {errors.email && (
                          <p className="text-red-500 dark:text-red-400 text-sm mt-1 flex items-center gap-1">
                            <i className="ri-error-warning-line"></i>
                            {errors.email}
                          </p>
                        )}
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Телефон *
                        </label>
                        <input
                          type="tel"
                          name="phone"
                          value={formData.phone}
                          onChange={handleInputChange}
                          className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:border-gray-900 dark:focus:border-gray-300 bg-white dark:bg-gray-700 text-gray-900 dark:text-white transition-colors ${
                            errors.phone ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'
                          }`}
                          placeholder="+7 (999) 123-45-67"
                        />
                        {errors.phone && (
                          <p className="text-red-500 dark:text-red-400 text-sm mt-1 flex items-center gap-1">
                            <i className="ri-error-warning-line"></i>
                            {errors.phone}
                          </p>
                        )}
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Адрес *
                      </label>
                      <input
                        type="text"
                        name="address"
                        value={formData.address}
                        onChange={handleInputChange}
                        className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:border-gray-900 dark:focus:border-gray-300 bg-white dark:bg-gray-700 text-gray-900 dark:text-white transition-colors ${
                          errors.address ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'
                        }`}
                        placeholder="ул. Ленина, д. 123"
                      />
                      {errors.address && (
                        <p className="text-red-500 dark:text-red-400 text-sm mt-1 flex items-center gap-1">
                          <i className="ri-error-warning-line"></i>
                          {errors.address}
                        </p>
                      )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Город *
                        </label>
                        <input
                          type="text"
                          name="city"
                          value={formData.city}
                          onChange={handleInputChange}
                          className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:border-gray-900 dark:focus:border-gray-300 bg-white dark:bg-gray-700 text-gray-900 dark:text-white transition-colors ${
                            errors.city ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'
                          }`}
                          placeholder="Москва"
                        />
                        {errors.city && (
                          <p className="text-red-500 dark:text-red-400 text-sm mt-1 flex items-center gap-1">
                            <i className="ri-error-warning-line"></i>
                            {errors.city}
                          </p>
                        )}
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Почтовый индекс *
                        </label>
                        <input
                          type="text"
                          name="postalCode"
                          value={formData.postalCode}
                          onChange={handleInputChange}
                          className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:border-gray-900 dark:focus:border-gray-300 bg-white dark:bg-gray-700 text-gray-900 dark:text-white transition-colors ${
                            errors.postalCode ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'
                          }`}
                          placeholder="123456"
                        />
                        {errors.postalCode && (
                          <p className="text-red-500 dark:text-red-400 text-sm mt-1 flex items-center gap-1">
                            <i className="ri-error-warning-line"></i>
                            {errors.postalCode}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-1">
                <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-sm sticky top-24 border border-gray-200 dark:border-gray-700 transition-colors">
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Итого заказа</h2>

                  <div className="space-y-4 mb-6 max-h-64 overflow-y-auto">
                    {cartItems.map((item) => (
                      <div key={item.id} className="flex gap-4">
                        <div className="w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-lg overflow-hidden flex-shrink-0">
                          <img
                            src={item.thumbnail}
                            alt={item.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium text-gray-900 dark:text-white line-clamp-2">
                            {item.title}
                          </p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">Кол-во: {item.quantity}</p>
                        </div>
                        <p className="text-sm font-bold text-gray-900 dark:text-white">
                          ${(item.price * item.quantity).toFixed(2)}
                        </p>
                      </div>
                    ))}
                  </div>

                  <div className="space-y-3 mb-6 border-t border-gray-200 dark:border-gray-700 pt-6">
                    <div className="flex justify-between text-gray-600 dark:text-gray-400">
                      <span>Подытог</span>
                      <span className="font-semibold text-gray-900 dark:text-white">${subtotal.toFixed(2)}</span>
                    </div>
                    
                    {appliedPromo && (
                      <div className="flex justify-between text-green-600 dark:text-green-400">
                        <span>Скидка ({appliedPromo.code})</span>
                        <span className="font-semibold">-${discount.toFixed(2)}</span>
                      </div>
                    )}
                    
                    <div className="flex justify-between text-gray-600 dark:text-gray-400">
                      <span>Доставка</span>
                      <span className="font-semibold text-gray-900 dark:text-white">
                        {shipping === 0 ? 'Бесплатно' : `$${shipping.toFixed(2)}`}
                      </span>
                    </div>
                    <div className="flex justify-between text-gray-600 dark:text-gray-400">
                      <span>Налог (10%)</span>
                      <span className="font-semibold text-gray-900 dark:text-white">${tax.toFixed(2)}</span>
                    </div>
                    <div className="border-t border-gray-200 dark:border-gray-700 pt-3">
                      <div className="flex justify-between">
                        <span className="text-xl font-bold text-gray-900 dark:text-white">Итого</span>
                        <span className="text-3xl font-bold text-gray-900 dark:text-white">
                          ${total.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-black dark:bg-white text-white dark:text-black py-4 rounded-lg font-medium hover:bg-gray-800 dark:hover:bg-gray-100 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 whitespace-nowrap"
                  >
                    {loading ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white dark:border-black"></div>
                        Обработка...
                      </>
                    ) : (
                      <>
                        <i className="ri-secure-payment-line text-xl"></i>
                        Оформить заказ
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </main>

      <Footer />
    </div>
  );
}
