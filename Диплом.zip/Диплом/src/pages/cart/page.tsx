import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';
import { promoCodes, type PromoCode } from '../../mocks/promoData';

interface CartItem {
  id: number;
  title: string;
  price: number;
  thumbnail: string;
  quantity: number;
}

interface AppliedPromo {
  code: string;
  discount: number;
}

export default function CartPage() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [promoCode, setPromoCode] = useState('');
  const [appliedPromo, setAppliedPromo] = useState<AppliedPromo | null>(null);
  const [promoError, setPromoError] = useState('');
  const [notification, setNotification] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    loadCart();
    loadAppliedPromo();
  }, []);

  const loadCart = () => {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    setCartItems(cart);
  };

  const loadAppliedPromo = () => {
    const saved = localStorage.getItem('appliedPromo');
    if (saved) {
      setAppliedPromo(JSON.parse(saved));
    }
  };

  const showNotification = (message: string) => {
    setNotification(message);
    setTimeout(() => setNotification(''), 3000);
  };

  const applyPromoCode = () => {
    setPromoError('');
    
    const code = promoCode.trim().toUpperCase();
    if (!code) {
      setPromoError('Введите промокод');
      return;
    }

    const promo = promoCodes.find((p) => p.code === code);
    
    if (!promo) {
      setPromoError('Неверный промокод');
      return;
    }

    const currentDate = new Date();
    const expiryDate = new Date(promo.expiryDate);
    
    if (currentDate > expiryDate) {
      setPromoError('Срок действия промокода истёк');
      return;
    }

    const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
    
    if (subtotal < promo.minOrderAmount) {
      setPromoError(`Минимальная сумма заказа для этого промокода: $${promo.minOrderAmount}`);
      return;
    }

    let discount = 0;
    if (promo.type === 'percent') {
      discount = subtotal * (promo.value / 100);
    } else {
      discount = promo.value;
    }

    const applied = { code: promo.code, discount };
    setAppliedPromo(applied);
    localStorage.setItem('appliedPromo', JSON.stringify(applied));
    setPromoCode('');
    showNotification(`Промокод применён! Скидка: $${discount.toFixed(2)}`);
  };

  const removePromoCode = () => {
    setAppliedPromo(null);
    localStorage.removeItem('appliedPromo');
    showNotification('Промокод удалён');
  };

  const updateQuantity = (id: number, newQuantity: number) => {
    if (newQuantity < 1) return;

    const updatedCart = cartItems.map((item) =>
      item.id === id ? { ...item, quantity: newQuantity } : item
    );
    setCartItems(updatedCart);
    localStorage.setItem('cart', JSON.stringify(updatedCart));
    window.dispatchEvent(new Event('cartUpdated'));
  };

  const removeItem = (id: number) => {
    const updatedCart = cartItems.filter((item) => item.id !== id);
    setCartItems(updatedCart);
    localStorage.setItem('cart', JSON.stringify(updatedCart));
    window.dispatchEvent(new Event('cartUpdated'));
  };

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const discount = appliedPromo ? appliedPromo.discount : 0;
  const subtotalAfterDiscount = subtotal - discount;
  const shipping = subtotalAfterDiscount > 50 ? 0 : 10;
  const tax = subtotalAfterDiscount * 0.1;
  const total = subtotalAfterDiscount + shipping + tax;

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
        <Header />
        <main className="pt-24 pb-20">
          <div className="max-w-[1400px] mx-auto px-8">
            <div className="flex flex-col items-center justify-center py-20">
              <i className="ri-shopping-cart-line text-8xl text-gray-300 dark:text-gray-600 mb-6"></i>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Ваша корзина пуста</h2>
              <p className="text-gray-600 dark:text-gray-400 mb-8">Добавьте товары, чтобы начать</p>
              <Link
                to="/catalog"
                className="bg-black dark:bg-white text-white dark:text-black px-8 py-4 rounded-lg font-medium hover:bg-gray-800 dark:hover:bg-gray-100 transition-colors whitespace-nowrap"
              >
                Смотреть товары
              </Link>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      <Header />

      {notification && (
        <div className="fixed top-24 right-8 bg-green-500 text-white px-6 py-4 rounded-lg shadow-lg z-50 flex items-center gap-3 animate-slide-in">
          <i className="ri-checkbox-circle-line text-2xl"></i>
          <span className="font-medium">{notification}</span>
        </div>
      )}

      <main className="pt-24 pb-20">
        <div className="max-w-[1400px] mx-auto px-8">
          <h1 className="text-5xl font-bold text-gray-900 dark:text-white mb-12">Корзина</h1>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-4">
              {cartItems.map((item) => (
                <div
                  key={item.id}
                  className="bg-white dark:bg-gray-800 rounded-2xl p-6 flex items-center gap-6 shadow-sm hover:shadow-md transition-all border border-gray-200 dark:border-gray-700"
                >
                  <Link to={`/product/${item.id}`} className="flex-shrink-0">
                    <div className="w-32 h-32 bg-gray-100 dark:bg-gray-700 rounded-xl overflow-hidden">
                      <img
                        src={item.thumbnail}
                        alt={item.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </Link>

                  <div className="flex-1">
                    <Link
                      to={`/product/${item.id}`}
                      className="text-xl font-semibold text-gray-900 dark:text-white hover:text-gray-700 dark:hover:text-gray-300 transition-colors"
                    >
                      {item.title}
                    </Link>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white mt-2">${item.price}</p>
                  </div>

                  <div className="flex items-center gap-6">
                    <div className="flex items-center border border-gray-300 dark:border-gray-600 rounded-lg">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors text-gray-900 dark:text-white"
                      >
                        <i className="ri-subtract-line"></i>
                      </button>
                      <input
                        type="number"
                        value={item.quantity}
                        onChange={(e) =>
                          updateQuantity(item.id, parseInt(e.target.value) || 1)
                        }
                        className="w-16 text-center border-x border-gray-300 dark:border-gray-600 py-2 focus:outline-none bg-transparent text-gray-900 dark:text-white"
                        min="1"
                      />
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors text-gray-900 dark:text-white"
                      >
                        <i className="ri-add-line"></i>
                      </button>
                    </div>

                    <p className="text-xl font-bold text-gray-900 dark:text-white w-24 text-right">
                      ${(item.price * item.quantity).toFixed(2)}
                    </p>

                    <button
                      onClick={() => removeItem(item.id)}
                      className="text-red-500 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300 transition-colors p-2"
                    >
                      <i className="ri-delete-bin-line text-2xl"></i>
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="lg:col-span-1">
              <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-sm sticky top-24 border border-gray-200 dark:border-gray-700 transition-colors">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Итого заказа</h2>

                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Промокод
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={promoCode}
                      onChange={(e) => {
                        setPromoCode(e.target.value.toUpperCase());
                        setPromoError('');
                      }}
                      placeholder="ВВЕДИТЕ КОД"
                      className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:border-gray-900 dark:focus:border-gray-300 bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm"
                      disabled={!!appliedPromo}
                    />
                    <button
                      onClick={applyPromoCode}
                      disabled={!!appliedPromo}
                      className="px-6 py-3 bg-black dark:bg-white text-white dark:text-black rounded-lg font-medium hover:bg-gray-800 dark:hover:bg-gray-100 transition-colors disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
                    >
                      Применить
                    </button>
                  </div>
                  {promoError && (
                    <p className="text-red-500 dark:text-red-400 text-sm mt-2 flex items-center gap-1">
                      <i className="ri-error-warning-line"></i>
                      {promoError}
                    </p>
                  )}
                  {appliedPromo && (
                    <div className="mt-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-3 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <i className="ri-checkbox-circle-fill text-green-600 dark:text-green-400"></i>
                        <span className="text-sm font-medium text-green-700 dark:text-green-300">
                          {appliedPromo.code}
                        </span>
                      </div>
                      <button
                        onClick={removePromoCode}
                        className="text-red-500 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300 transition-colors"
                      >
                        <i className="ri-close-line text-xl"></i>
                      </button>
                    </div>
                  )}
                </div>

                <div className="space-y-4 mb-6">
                  <div className="flex justify-between text-gray-600 dark:text-gray-400">
                    <span>Подытог</span>
                    <span className="font-semibold text-gray-900 dark:text-white">${subtotal.toFixed(2)}</span>
                  </div>
                  
                  {appliedPromo && (
                    <div className="flex justify-between text-green-600 dark:text-green-400">
                      <span>Скидка ({appliedPromo.code})</span>
                      <span className="font-semibold">-${discount.toFixed(2)}</span>
                    </div>
                  )}
                  
                  <div className="flex justify-between text-gray-600 dark:text-gray-400">
                    <span>Доставка</span>
                    <span className="font-semibold text-gray-900 dark:text-white">
                      {shipping === 0 ? 'Бесплатно' : `$${shipping.toFixed(2)}`}
                    </span>
                  </div>
                  <div className="flex justify-between text-gray-600 dark:text-gray-400">
                    <span>Налог (10%)</span>
                    <span className="font-semibold text-gray-900 dark:text-white">${tax.toFixed(2)}</span>
                  </div>

                  {subtotalAfterDiscount < 50 && (
                    <div className="bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg p-3">
                      <p className="text-sm text-gray-700 dark:text-gray-300">
                        Добавьте ещё на ${(50 - subtotalAfterDiscount).toFixed(2)} для бесплатной доставки!
                      </p>
                    </div>
                  )}

                  <div className="border-t border-gray-200 dark:border-gray-700 pt-4">
                    <div className="flex justify-between">
                      <span className="text-xl font-bold text-gray-900 dark:text-white">Итого</span>
                      <span className="text-3xl font-bold text-gray-900 dark:text-white">
                        ${total.toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => navigate('/checkout')}
                  className="w-full bg-black dark:bg-white text-white dark:text-black py-4 rounded-lg font-medium hover:bg-gray-800 dark:hover:bg-gray-100 transition-colors mb-4 whitespace-nowrap"
                >
                  Оформить заказ
                </button>

                <Link
                  to="/catalog"
                  className="block text-center text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors whitespace-nowrap"
                >
                  Продолжить покупки
                </Link>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
