
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';

interface CompareProduct {
  id: number;
  title: string;
  price: number;
  thumbnail: string;
  rating?: number;
  category: string;
  brand?: string;
  description?: string;
  stock?: number;
}

export default function ComparePage() {
  const [compareProducts, setCompareProducts] = useState<CompareProduct[]>([]);

  useEffect(() => {
    loadCompareProducts();
  }, []);

  const loadCompareProducts = () => {
    const savedProducts = localStorage.getItem('compareProducts');
    if (savedProducts) {
      try {
        const products = JSON.parse(savedProducts);
        setCompareProducts(products);
      } catch (error) {
        console.error('Error loading compare products:', error);
        setCompareProducts([]);
      }
    }
  };

  const removeFromCompare = (id: number) => {
    const updatedList = compareProducts.filter((product) => product.id !== id);
    setCompareProducts(updatedList);
    
    // Update both localStorage items
    localStorage.setItem('compareProducts', JSON.stringify(updatedList));
    const compareIds = updatedList.map(p => p.id);
    localStorage.setItem('compareList', JSON.stringify(compareIds));
    
    window.dispatchEvent(new Event('compareUpdated'));
  };

  const clearAll = () => {
    setCompareProducts([]);
    localStorage.setItem('compareProducts', JSON.stringify([]));
    localStorage.setItem('compareList', JSON.stringify([]));
    window.dispatchEvent(new Event('compareUpdated'));
  };

  if (compareProducts.length === 0) {
    return (
      <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors">
        <Header />
        <main className="pt-24 pb-20">
          <div className="max-w-[1400px] mx-auto px-8">
            <div className="flex flex-col items-center justify-center py-20">
              <i className="ri-scales-3-line text-8xl text-gray-300 dark:text-gray-600 mb-6"></i>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                Нет товаров для сравнения
              </h2>
              <p className="text-gray-600 dark:text-gray-400 mb-8">
                Добавьте товары из каталога, чтобы сравнить их
              </p>
              <Link
                to="/catalog"
                className="bg-black dark:bg-white text-white dark:text-black px-8 py-4 rounded-lg font-medium hover:bg-gray-800 dark:hover:bg-gray-100 transition-colors whitespace-nowrap"
              >
                Смотреть товары
              </Link>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors">
      <Header />

      <main className="pt-24 pb-20">
        <div className="max-w-[1400px] mx-auto px-8">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white">
              Сравнение товаров
            </h1>
            <button
              onClick={clearAll}
              className="text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300 font-medium whitespace-nowrap"
            >
              Очистить всё
            </button>
          </div>

          <div className="overflow-x-auto">
            <div className="inline-block min-w-full">
              <div className="grid gap-6" style={{ gridTemplateColumns: `repeat(${compareProducts.length}, minmax(280px, 1fr))` }}>
                {compareProducts.map((product) => (
                  <div
                    key={product.id}
                    className="bg-gray-50 dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700 transition-colors"
                  >
                    <div className="flex justify-end mb-4">
                      <button
                        onClick={() => removeFromCompare(product.id)}
                        className="text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300 transition-colors"
                      >
                        <i className="ri-close-line text-2xl"></i>
                      </button>
                    </div>

                    <Link to={`/product/${product.id}`} className="block mb-4">
                      <div className="w-full h-64 bg-white dark:bg-gray-700 rounded-lg overflow-hidden">
                        <img
                          src={product.thumbnail}
                          alt={product.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </Link>

                    <div className="space-y-4">
                      <div>
                        <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">
                          Название товара
                        </h3>
                        <Link
                          to={`/product/${product.id}`}
                          className="text-lg font-semibold text-gray-900 dark:text-white hover:text-gray-700 dark:hover:text-gray-300 transition-colors line-clamp-2"
                        >
                          {product.title}
                        </Link>
                      </div>

                      <div>
                        <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">
                          Цена
                        </h3>
                        <p className="text-2xl font-bold text-gray-900 dark:text-white">
                          ${product.price}
                        </p>
                      </div>

                      {product.rating !== undefined && (
                        <div>
                          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">
                            Рейтинг
                          </h3>
                          <div className="flex items-center gap-2">
                            <div className="flex items-center">
                              {[...Array(5)].map((_, i) => (
                                <i
                                  key={i}
                                  className={`${
                                    i < Math.floor(product.rating || 0)
                                      ? 'ri-star-fill text-yellow-500'
                                      : 'ri-star-line text-gray-300 dark:text-gray-600'
                                  } text-lg`}
                                ></i>
                              ))}
                            </div>
                            <span className="text-sm text-gray-600 dark:text-gray-400">
                              {product.rating.toFixed(1)}
                            </span>
                          </div>
                        </div>
                      )}

                      <div>
                        <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">
                          Категория
                        </h3>
                        <p className="text-gray-900 dark:text-white capitalize">
                          {product.category}
                        </p>
                      </div>

                      {product.brand && (
                        <div>
                          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">
                            Бренд
                          </h3>
                          <p className="text-gray-900 dark:text-white">
                            {product.brand}
                          </p>
                        </div>
                      )}

                      {product.stock !== undefined && (
                        <div>
                          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">
                            Наличие
                          </h3>
                          <p className={`font-medium ${product.stock > 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                            {product.stock > 0 ? `В наличии: ${product.stock} шт.` : 'Нет в наличии'}
                          </p>
                        </div>
                      )}

                      {product.description && (
                        <div>
                          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">
                            Описание
                          </h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-3">
                            {product.description}
                          </p>
                        </div>
                      )}

                      <Link
                        to={`/product/${product.id}`}
                        className="block w-full bg-black dark:bg-white text-white dark:text-black text-center py-3 rounded-lg font-medium hover:bg-gray-800 dark:hover:bg-gray-100 transition-colors whitespace-nowrap"
                      >
                        Подробнее
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
