
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';
import { profileUser } from '../../mocks/profileData';

export default function ProfilePage() {
  const [activeTab, setActiveTab] = useState<'overview' | 'orders' | 'addresses'>('overview');
  const [wishlistCount, setWishlistCount] = useState(0);

  useEffect(() => {
    const updateWishlistCount = () => {
      const wishlist = JSON.parse(localStorage.getItem('wishlist') || '[]');
      setWishlistCount(wishlist.length);
    };

    updateWishlistCount();
    window.addEventListener('storage', updateWishlistCount);
    window.addEventListener('wishlistUpdated', updateWishlistCount);

    return () => {
      window.removeEventListener('storage', updateWishlistCount);
      window.removeEventListener('wishlistUpdated', updateWishlistCount);
    };
  }, []);

  const tabs = [
    { key: 'overview' as const, label: 'Обзор', icon: 'ri-user-line' },
    { key: 'orders' as const, label: 'Заказы', icon: 'ri-file-list-3-line' },
    { key: 'addresses' as const, label: 'Адреса', icon: 'ri-map-pin-line' },
  ];

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <Header />

      <main className="pt-[72px]">
        {/* Hero Banner */}
        <section className="relative h-[280px] bg-gray-100 dark:bg-gray-800 overflow-hidden">
          <img
            src="https://readdy.ai/api/search-image?query=A%20minimal%20abstract%20geometric%20pattern%20with%20soft%20warm%20tones%20of%20beige%20cream%20and%20light%20gray%20creating%20a%20calm%20elegant%20background%20texture%20with%20subtle%20gradients%20and%20clean%20lines%20suitable%20for%20a%20profile%20page%20banner&width=1920&height=400&seq=profile-banner-001&orientation=landscape"
            alt="Profile banner"
            className="w-full h-full object-cover object-top opacity-40 dark:opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-white dark:to-gray-900"></div>
        </section>

        <div className="max-w-[1100px] mx-auto px-8 -mt-24 relative z-10 pb-20">
          {/* Profile Card */}
          <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 shadow-lg p-8 mb-8">
            <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
              <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-white dark:border-gray-700 shadow-md flex-shrink-0">
                <img
                  src={profileUser.avatar}
                  alt={profileUser.name}
                  className="w-full h-full object-cover object-top"
                />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-1">
                  <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{profileUser.name}</h1>
                  <span className="bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 text-xs font-semibold px-3 py-1 rounded-full whitespace-nowrap">
                    {profileUser.tier}
                  </span>
                </div>
                <p className="text-sm text-gray-500 dark:text-gray-400">{profileUser.email}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">Участник с {profileUser.memberSince}</p>
              </div>
              <Link
                to="/feedback"
                className="bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900 px-5 py-2.5 rounded-lg text-sm font-medium hover:bg-gray-800 dark:hover:bg-gray-200 transition-colors whitespace-nowrap cursor-pointer"
              >
                Оставить отзыв
              </Link>
            </div>
          </div>

          {/* Wallet Card */}
          <div className="bg-gray-900 dark:bg-gray-100 rounded-lg p-8 mb-8 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 dark:bg-black/5 rounded-full -translate-y-1/2 translate-x-1/2"></div>
            <div className="absolute bottom-0 left-0 w-40 h-40 bg-white/5 dark:bg-black/5 rounded-full translate-y-1/2 -translate-x-1/2"></div>
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-5 h-5 flex items-center justify-center">
                  <i className="ri-wallet-3-line text-gray-400 dark:text-gray-500"></i>
                </div>
                <p className="text-sm text-gray-400 dark:text-gray-500 font-medium">Баланс кошелька</p>
              </div>
              <p className="text-5xl font-bold text-white dark:text-gray-900 mb-1">
                ${profileUser.walletBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </p>
              <p className="text-sm text-gray-400 dark:text-gray-500 mt-3">Доступно для покупок</p>
            </div>
          </div>

          {/* Stats Row */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
            <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6 text-center">
              <div className="w-10 h-10 flex items-center justify-center mx-auto mb-3 bg-gray-100 dark:bg-gray-700 rounded-full">
                <i className="ri-shopping-bag-line text-xl text-gray-700 dark:text-gray-300"></i>
              </div>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">{profileUser.totalOrders}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Всего заказов</p>
            </div>
            <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6 text-center">
              <div className="w-10 h-10 flex items-center justify-center mx-auto mb-3 bg-gray-100 dark:bg-gray-700 rounded-full">
                <i className="ri-heart-line text-xl text-gray-700 dark:text-gray-300"></i>
              </div>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">{wishlistCount}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Список желаний</p>
            </div>
            <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6 text-center">
              <div className="w-10 h-10 flex items-center justify-center mx-auto mb-3 bg-gray-100 dark:bg-gray-700 rounded-full">
                <i className="ri-star-line text-xl text-gray-700 dark:text-gray-300"></i>
              </div>
              <p className="text-3xl font-bold text-gray-900 dark:text-white">{profileUser.tier}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Уровень членства</p>
            </div>
          </div>

          {/* Tabs */}
          <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
            <div className="flex border-b border-gray-200 dark:border-gray-700">
              {tabs.map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={`flex items-center gap-2 px-6 py-4 text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                    activeTab === tab.key
                      ? 'text-gray-900 dark:text-white border-b-2 border-gray-900 dark:border-white -mb-px'
                      : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                  }`}
                >
                  <div className="w-4 h-4 flex items-center justify-center">
                    <i className={`${tab.icon} text-base`}></i>
                  </div>
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="p-8">
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Личная информация</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wider">Полное имя</label>
                      <p className="text-gray-900 dark:text-white font-medium mt-1">{profileUser.name}</p>
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wider">Email</label>
                      <p className="text-gray-900 dark:text-white font-medium mt-1">{profileUser.email}</p>
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wider">Телефон</label>
                      <p className="text-gray-900 dark:text-white font-medium mt-1">{profileUser.phone}</p>
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wider">Участник с</label>
                      <p className="text-gray-900 dark:text-white font-medium mt-1">{profileUser.memberSince}</p>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'orders' && (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Последние заказы</h3>
                    <Link
                      to="/orders"
                      className="text-sm font-medium text-gray-900 dark:text-white hover:opacity-70 transition-opacity cursor-pointer whitespace-nowrap"
                    >
                      Смотреть все →
                    </Link>
                  </div>
                  <div className="space-y-3">
                    {profileUser.recentOrders.map((order) => (
                      <div
                        key={order.id}
                        className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg"
                      >
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 flex items-center justify-center bg-white dark:bg-gray-600 rounded-lg">
                            <i className="ri-box-3-line text-lg text-gray-600 dark:text-gray-300"></i>
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-gray-900 dark:text-white">{order.id}</p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">{order.date} &middot; {order.items} товар{order.items > 1 ? (order.items > 4 ? 'ов' : 'а') : ''}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-bold text-gray-900 dark:text-white">${order.total.toFixed(2)}</p>
                          <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400">{order.status}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === 'addresses' && (
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Сохранённые адреса</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {profileUser.addresses.map((addr, idx) => (
                      <div
                        key={idx}
                        className="p-5 bg-gray-50 dark:bg-gray-700/50 rounded-lg border border-gray-200 dark:border-gray-600"
                      >
                        <div className="flex items-center gap-2 mb-2">
                          <div className="w-4 h-4 flex items-center justify-center">
                            <i className={`${addr.label === 'Дом' ? 'ri-home-4-line' : 'ri-building-line'} text-base text-gray-700 dark:text-gray-300`}></i>
                          </div>
                          <span className="text-sm font-semibold text-gray-900 dark:text-white">{addr.label}</span>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">{addr.address}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
