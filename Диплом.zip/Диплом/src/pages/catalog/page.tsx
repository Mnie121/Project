import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';

interface Product {
  id: number;
  title: string;
  price: number;
  thumbnail: string;
  category: string;
  rating: number;
  brand?: string;
  description?: string;
  stock?: number;
}

export default function CatalogPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [compareList, setCompareList] = useState<number[]>([]);
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [showCompareNotification, setShowCompareNotification] = useState<{
    show: boolean;
    message: string;
    type: 'success' | 'error';
  }>({ show: false, message: '', type: 'success' });

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState('default');

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true);
        const response = await fetch('https://dummyjson.com/products?limit=100');
        if (!response.ok) throw new Error('Failed to fetch products');
        const data = await response.json();
        setProducts(data.products);
        setFilteredProducts(data.products);

        const uniqueCategories = Array.from(
          new Set(data.products.map((p: Product) => p.category))
        ) as string[];
        setCategories(uniqueCategories);
      } catch (err) {
        setError('Не удалось загрузить товары. Пожалуйста, попробуйте позже.');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
    
    // Load compare list from localStorage
    const savedCompare = localStorage.getItem('compareList');
    if (savedCompare) {
      setCompareList(JSON.parse(savedCompare));
    }

    // Load wishlist from localStorage
    const savedWishlist = JSON.parse(localStorage.getItem('wishlist') || '[]');
    setWishlist(savedWishlist.map((item: any) => item.id));
  }, []);

  useEffect(() => {
    let result = [...products];

    if (searchQuery) {
      result = result.filter((product) =>
        product.title.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (selectedCategory !== 'all') {
      result = result.filter((product) => product.category === selectedCategory);
    }

    if (sortBy === 'price-asc') {
      result.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-desc') {
      result.sort((a, b) => b.price - a.price);
    } else if (sortBy === 'rating') {
      result.sort((a, b) => b.rating - a.rating);
    }

    setFilteredProducts(result);
  }, [searchQuery, selectedCategory, sortBy, products]);

  const addToCompare = (product: Product, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    // If already in compare list — remove
    if (compareList.includes(product.id)) {
      const newCompareList = compareList.filter((id) => id !== product.id);
      setCompareList(newCompareList);
      localStorage.setItem('compareList', JSON.stringify(newCompareList));

      const compareProducts = JSON.parse(localStorage.getItem('compareProducts') || '[]');
      const updatedProducts = compareProducts.filter((p: Product) => p.id !== product.id);
      localStorage.setItem('compareProducts', JSON.stringify(updatedProducts));

      window.dispatchEvent(new Event('compareUpdated'));

      setShowCompareNotification({
        show: true,
        message: 'Удалено из сравнения',
        type: 'success',
      });
      setTimeout(() => setShowCompareNotification({ show: false, message: '', type: 'success' }), 3000);
      return;
    }

    if (compareList.length >= 4) {
      setShowCompareNotification({
        show: true,
        message: 'Максимум 4 товара для сравнения',
        type: 'error',
      });
      setTimeout(() => setShowCompareNotification({ show: false, message: '', type: 'success' }), 3000);
      return;
    }

    const newCompareList = [...compareList, product.id];
    setCompareList(newCompareList);
    localStorage.setItem('compareList', JSON.stringify(newCompareList));

    // Save full product data
    const compareProducts = JSON.parse(localStorage.getItem('compareProducts') || '[]');
    compareProducts.push(product);
    localStorage.setItem('compareProducts', JSON.stringify(compareProducts));

    window.dispatchEvent(new Event('compareUpdated'));

    setShowCompareNotification({
      show: true,
      message: 'Добавлено в сравнение',
      type: 'success',
    });
    setTimeout(() => setShowCompareNotification({ show: false, message: '', type: 'success' }), 3000);
  };

  const toggleWishlist = (product: Product, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    const saved: any[] = JSON.parse(localStorage.getItem('wishlist') || '[]');
    const exists = saved.find((item) => item.id === product.id);

    if (exists) {
      const updated = saved.filter((item) => item.id !== product.id);
      localStorage.setItem('wishlist', JSON.stringify(updated));
      setWishlist(updated.map((item) => item.id));
      setShowCompareNotification({
        show: true,
        message: 'Удалено из желаемого',
        type: 'success',
      });
    } else {
      const newItem = {
        id: product.id,
        title: product.title,
        price: product.price,
        thumbnail: product.thumbnail,
        category: product.category,
        rating: product.rating,
      };
      saved.push(newItem);
      localStorage.setItem('wishlist', JSON.stringify(saved));
      setWishlist(saved.map((item) => item.id));
      setShowCompareNotification({
        show: true,
        message: 'Добавлено в желаемое',
        type: 'success',
      });
    }

    window.dispatchEvent(new Event('wishlistUpdated'));
    setTimeout(() => setShowCompareNotification({ show: false, message: '', type: 'success' }), 3000);
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      <Header />

      {showCompareNotification.show && (
        <div
          className={`fixed top-24 right-8 px-6 py-4 rounded-lg shadow-xl z-50 animate-fade-in ${
            showCompareNotification.type === 'success'
              ? 'bg-green-500 text-white'
              : 'bg-red-500 text-white'
          }`}
        >
          <div className="flex items-center gap-3">
            <i
              className={`text-2xl ${
                showCompareNotification.type === 'success'
                  ? 'ri-checkbox-circle-line'
                  : 'ri-error-warning-line'
              }`}
            ></i>
            <span className="font-medium">{showCompareNotification.message}</span>
          </div>
        </div>
      )}

      <main className="pt-24 pb-20">
        <div className="max-w-[1400px] mx-auto px-8">
          <div className="mb-12">
            <h1 className="text-5xl font-bold text-gray-900 dark:text-white mb-4">Каталог товаров</h1>
            <p className="text-gray-600 dark:text-gray-400">Просмотрите нашу полную коллекцию качественных товаров</p>
          </div>

          <div className="bg-gray-50 dark:bg-gray-800 rounded-2xl shadow-sm p-6 mb-8 sticky top-24 z-40">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="relative">
                <i className="ri-search-line absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-500 text-xl"></i>
                <input
                  type="text"
                  placeholder="Поиск товаров..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:border-gray-900 dark:focus:border-gray-400 text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                />
              </div>

              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:border-gray-900 dark:focus:border-gray-400 text-sm cursor-pointer bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              >
                <option value="all">Все категории</option>
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category.charAt(0).toUpperCase() + category.slice(1)}
                  </option>
                ))}
              </select>

              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:border-gray-900 dark:focus:border-gray-400 text-sm cursor-pointer bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              >
                <option value="default">Сортировка</option>
                <option value="price-asc">Цена: по возрастанию</option>
                <option value="price-desc">Цена: по убыванию</option>
                <option value="rating">По рейтингу</option>
              </select>
            </div>
          </div>

          {loading && (
            <div className="flex justify-center items-center py-20">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900 dark:border-gray-100"></div>
            </div>
          )}

          {error && (
            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-400 px-6 py-4 rounded-lg">
              {error}
            </div>
          )}

          {!loading && !error && filteredProducts.length === 0 && (
            <div className="text-center py-20">
              <i className="ri-search-line text-6xl text-gray-300 dark:text-gray-600 mb-4"></i>
              <p className="text-xl text-gray-600 dark:text-gray-400">Товары не найдены</p>
              <p className="text-gray-500 dark:text-gray-500 mt-2">Попробуйте изменить параметры поиска или фильтры</p>
            </div>
          )}

          {!loading && !error && filteredProducts.length > 0 && (
            <>
              <div className="mb-6">
                <p className="text-gray-600 dark:text-gray-400">
                  Показано <span className="font-semibold">{filteredProducts.length}</span> товаров
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8" data-product-shop>
                {filteredProducts.map((product) => (
                  <div key={product.id} className="relative group">
                    <Link
                      to={`/product/${product.id}`}
                      className="block bg-white dark:bg-gray-800 rounded-2xl overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border border-gray-200 dark:border-gray-700"
                    >
                      <div className="aspect-square overflow-hidden bg-gray-100 dark:bg-gray-700">
                        <img
                          src={product.thumbnail}
                          alt={product.title}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                        />
                      </div>
                      <div className="p-6">
                        <p className="text-xs text-gray-500 dark:text-gray-400 uppercase mb-2">{product.category}</p>
                        <h3 className="font-semibold text-gray-900 dark:text-white mb-3 line-clamp-2 min-h-[3rem]">
                          {product.title}
                        </h3>
                        <div className="flex items-center justify-between">
                          <p className="text-2xl font-bold text-gray-900 dark:text-white">${product.price}</p>
                          <div className="flex items-center gap-1">
                            <i className="ri-star-fill text-yellow-400 text-sm"></i>
                            <span className="text-sm text-gray-600 dark:text-gray-400">{product.rating}</span>
                          </div>
                        </div>
                      </div>
                    </Link>
                    <div className="absolute top-4 right-4 flex flex-col gap-2">
                      <button
                        onClick={(e) => toggleWishlist(product, e)}
                        className={`w-10 h-10 flex items-center justify-center rounded-full transition-all shadow-lg cursor-pointer ${
                          wishlist.includes(product.id)
                            ? 'bg-red-500 text-white'
                            : 'bg-white dark:bg-gray-800 text-gray-900 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700'
                        }`}
                        title={wishlist.includes(product.id) ? 'Удалить из желаемого' : 'Добавить в желаемое'}
                      >
                        <i className={`text-lg ${wishlist.includes(product.id) ? 'ri-heart-fill' : 'ri-heart-line'}`}></i>
                      </button>
                      <button
                        onClick={(e) => addToCompare(product, e)}
                        className={`w-10 h-10 flex items-center justify-center rounded-full transition-all ${
                          compareList.includes(product.id)
                            ? 'bg-gray-900 dark:bg-gray-100 text-white dark:text-gray-900'
                            : 'bg-white dark:bg-gray-800 text-gray-900 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700'
                        } shadow-lg cursor-pointer`}
                        title={compareList.includes(product.id) ? 'Удалить из сравнения' : 'Добавить к сравнению'}
                      >
                        <i
                          className={`text-lg ${
                            compareList.includes(product.id)
                              ? 'ri-scales-3-fill'
                              : 'ri-scales-3-line'
                          }`}
                        ></i>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
