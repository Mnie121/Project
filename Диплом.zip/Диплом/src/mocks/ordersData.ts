export interface OrderItem {
  id: number;
  title: string;
  price: number;
  quantity: number;
  thumbnail: string;
}

export interface Order {
  id: string;
  date: string;
  status: 'delivered' | 'in-transit' | 'processing' | 'cancelled';
  items: OrderItem[];
  subtotal: number;
  discount: number;
  promoCode?: string;
  shipping: number;
  tax: number;
  total: number;
  shippingAddress: {
    fullName: string;
    address: string;
    city: string;
    postalCode: string;
    phone: string;
  };
}

export const mockOrders: Order[] = [
  {
    id: 'ORD-2025-001',
    date: '2025-01-15',
    status: 'delivered',
    items: [
      {
        id: 1,
        title: 'Беспроводные наушники Premium',
        price: 299.99,
        quantity: 1,
        thumbnail: 'https://readdy.ai/api/search-image?query=Premium%20wireless%20headphones%20with%20sleek%20modern%20design%20in%20matte%20black%20color%20on%20simple%20clean%20white%20background%20product%20photography%20style&width=400&height=400&seq=order-item-001&orientation=squarish'
      },
      {
        id: 2,
        title: 'Умные часы Pro',
        price: 399.99,
        quantity: 1,
        thumbnail: 'https://readdy.ai/api/search-image?query=Modern%20smartwatch%20with%20elegant%20black%20band%20and%20bright%20display%20showing%20fitness%20data%20on%20simple%20clean%20white%20background%20product%20photography%20style&width=400&height=400&seq=order-item-002&orientation=squarish'
      }
    ],
    subtotal: 699.98,
    discount: 69.99,
    promoCode: 'WELCOME10',
    shipping: 0,
    tax: 63.00,
    total: 692.99,
    shippingAddress: {
      fullName: 'Вася Пупкин',
      address: 'улица Улугбека 55',
      city: 'Алматы',
      postalCode: '101000',
      phone: '+7 701 987 6543'
    }
  },
  {
    id: 'ORD-2025-002',
    date: '2025-01-10',
    status: 'in-transit',
    items: [
      {
        id: 3,
        title: 'Портативная колонка Bluetooth',
        price: 149.99,
        quantity: 2,
        thumbnail: 'https://readdy.ai/api/search-image?query=Compact%20portable%20bluetooth%20speaker%20in%20vibrant%20blue%20color%20with%20modern%20cylindrical%20design%20on%20simple%20clean%20white%20background%20product%20photography%20style&width=400&height=400&seq=order-item-003&orientation=squarish'
      }
    ],
    subtotal: 299.98,
    discount: 59.99,
    promoCode: 'SAVE20',
    shipping: 0,
    tax: 24.00,
    total: 263.99,
    shippingAddress: {
      fullName: 'Вася Пупкин',
      address: 'улица Улугбека 55',
      city: 'Алматы',
      postalCode: '101000',
      phone: '+7 701 987 6543'
    }
  },
  {
    id: 'ORD-2025-003',
    date: '2025-01-05',
    status: 'processing',
    items: [
      {
        id: 4,
        title: 'Игровая мышь RGB',
        price: 79.99,
        quantity: 1,
        thumbnail: 'https://readdy.ai/api/search-image?query=Gaming%20mouse%20with%20colorful%20RGB%20lighting%20effects%20and%20ergonomic%20black%20design%20on%20simple%20clean%20white%20background%20product%20photography%20style&width=400&height=400&seq=order-item-004&orientation=squarish'
      },
      {
        id: 5,
        title: 'Механическая клавиатура',
        price: 159.99,
        quantity: 1,
        thumbnail: 'https://readdy.ai/api/search-image?query=Mechanical%20gaming%20keyboard%20with%20RGB%20backlight%20and%20black%20aluminum%20frame%20on%20simple%20clean%20white%20background%20product%20photography%20style&width=400&height=400&seq=order-item-005&orientation=squarish'
      }
    ],
    subtotal: 239.98,
    discount: 0,
    shipping: 0,
    tax: 23.99,
    total: 263.97,
    shippingAddress: {
      fullName: 'Вася Пупкин',
      address: 'улица Улугбека 55',
      city: 'Алматы',
      postalCode: '101000',
      phone: '+7 701 987 6543'
    }
  },
  {
    id: 'ORD-2024-045',
    date: '2024-12-28',
    status: 'delivered',
    items: [
      {
        id: 6,
        title: 'Фитнес-трекер',
        price: 129.99,
        quantity: 1,
        thumbnail: 'https://readdy.ai/api/search-image?query=Sleek%20fitness%20tracker%20band%20in%20black%20color%20with%20small%20display%20showing%20heart%20rate%20on%20simple%20clean%20white%20background%20product%20photography%20style&width=400&height=400&seq=order-item-006&orientation=squarish'
      }
    ],
    subtotal: 129.99,
    discount: 15.00,
    promoCode: 'FIXED15',
    shipping: 0,
    tax: 11.49,
    total: 126.48,
    shippingAddress: {
      fullName: 'Вася Пупкин',
      address: 'улица Улугбека 55',
      city: 'Алматы',
      postalCode: '101000',
      phone: '+7 701 987 6543'
    }
  },
  {
    id: 'ORD-2024-038',
    date: '2024-12-20',
    status: 'cancelled',
    items: [
      {
        id: 7,
        title: 'Веб-камера HD',
        price: 89.99,
        quantity: 1,
        thumbnail: 'https://readdy.ai/api/search-image?query=Modern%20HD%20webcam%20with%20clip%20mount%20in%20black%20color%20on%20simple%20clean%20white%20background%20product%20photography%20style&width=400&height=400&seq=order-item-007&orientation=squarish'
      }
    ],
    subtotal: 89.99,
    discount: 0,
    shipping: 10.00,
    tax: 8.99,
    total: 108.98,
    shippingAddress: {
      fullName: 'Вася Пупкин',
      address: 'улица Улугбека 55',
      city: 'Алматы',
      postalCode: '101000',
      phone: '+7 701 987 6543'
    }
  },
  {
    id: 'ORD-2024-032',
    date: '2024-12-15',
    status: 'delivered',
    items: [
      {
        id: 8,
        title: 'USB-C хаб 7-в-1',
        price: 49.99,
        quantity: 2,
        thumbnail: 'https://readdy.ai/api/search-image?query=Compact%20USB-C%20hub%20adapter%20with%20multiple%20ports%20in%20sleek%20gray%20aluminum%20finish%20on%20simple%20clean%20white%20background%20product%20photography%20style&width=400&height=400&seq=order-item-008&orientation=squarish'
      },
      {
        id: 9,
        title: 'Беспроводное зарядное устройство',
        price: 39.99,
        quantity: 1,
        thumbnail: 'https://readdy.ai/api/search-image?query=Wireless%20charging%20pad%20in%20minimalist%20black%20design%20with%20LED%20indicator%20on%20simple%20clean%20white%20background%20product%20photography%20style&width=400&height=400&seq=order-item-009&orientation=squarish'
      }
    ],
    subtotal: 139.97,
    discount: 0,
    shipping: 0,
    tax: 13.99,
    total: 153.96,
    shippingAddress: {
      fullName: 'Вася Пупкин',
      address: 'улица Улугбека 55',
      city: 'Алматы',
      postalCode: '101000',
      phone: '+7 701 987 6543'
    }
  }
];
