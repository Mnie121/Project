export interface PromoCode {
  code: string;
  type: 'percent' | 'fixed';
  value: number;
  minOrderAmount: number;
  expiryDate: string;
  description: string;
}

export const promoCodes: PromoCode[] = [
  {
    code: 'WELCOME10',
    type: 'percent',
    value: 10,
    minOrderAmount: 0,
    expiryDate: '2026-05-12',
    description: 'Скидка 10% на первый заказ'
  },
  {
    code: 'SAVE20',
    type: 'percent',
    value: 20,
    minOrderAmount: 100,
    expiryDate: '2026-05-12',
    description: 'Скидка 20% при заказе от $100'
  },
  {
    code: 'FIXED15',
    type: 'fixed',
    value: 15,
    minOrderAmount: 50,
    expiryDate: '2026-05-12',
    description: 'Скидка $15 при заказе от $50'
  },
  {
    code: 'MEGA30',
    type: 'percent',
    value: 30,
    minOrderAmount: 200,
    expiryDate: '2026-05-12',
    description: 'Скидка 30% при заказе от $200'
  },
  {
    code: 'EXPIRED',
    type: 'percent',
    value: 0,
    minOrderAmount: 0,
    expiryDate: '2025-12-29',
    description: 'Истёкший промокод'
  }
];
