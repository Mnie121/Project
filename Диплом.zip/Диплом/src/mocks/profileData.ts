
export const profileUser = {
  name: 'Вася Пупкин',
  email: 'vasya.pupkin@email.com',
  phone: '+7 701 987 6543',
  avatar: 'https://ichef.bbci.co.uk/ace/ws/640/cpsprodpb/1352A/production/_103464197_luke-watkin.gif.webp',
  walletBalance: 1284.50,
  memberSince: 'Январь 2024',
  tier: 'Золотой участник',
  totalOrders: 47,
  recentOrders: [
    { id: 'ORD-20251201', date: '1 дек 2025', total: 129.99, status: 'Доставлен', items: 3 },
    { id: 'ORD-20251118', date: '18 ноя 2025', total: 74.50, status: 'Доставлен', items: 2 },
    { id: 'ORD-20251105', date: '5 ноя 2025', total: 249.00, status: 'Доставлен', items: 1 },
    { id: 'ORD-20251022', date: '22 окт 2025', total: 56.80, status: 'Доставлен', items: 4 },
  ],
  addresses: [
    { label: 'Дом', address: 'улица Улугбека 55, Алматы' },
    { label: 'Офис', address: 'город, 13, улица Улугбека 9, Алматы' },
  ],
};
