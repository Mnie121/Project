import type { Config } from 'tailwindcss'

export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#f5f7fa',
          100: '#eaeef4',
          200: '#d0dae7',
          300: '#a8bbd1',
          400: '#7896b7',
          500: '#5778a0',
          600: '#445f85',
          700: '#384d6d',
          800: '#31425c',
          900: '#2c394e',
        },
      },
    },
  },
  plugins: [],
} satisfies Config
